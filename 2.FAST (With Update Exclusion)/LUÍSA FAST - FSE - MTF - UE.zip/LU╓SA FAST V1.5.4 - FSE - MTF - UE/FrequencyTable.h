#if !defined(FREQUENCYTABLE_H)
#define FREQUENCYTABLE_H

#include <stdlib.h>
#include <stdio.h>

typedef struct FrequencyTable{
    int *Frequences;
    int Total;
    int Size;
} FrequencyTable;

//CONSTRUCTOR
FrequencyTable* FrequencyTableCreate(int ContextsAmount);

//CHECKING
int FrequencyTableGetSymbolLimit(FrequencyTable *ReceivedTable);

//OPERATIONAL
void FrequencyTableInsertOn(int Symbol, FrequencyTable *ReceivedTable);
int FrequencyTableGetTotal(FrequencyTable *ReceivedTable);
int FrequencyTableGetFrequency(int Symbol, FrequencyTable *ReceivedTable);
int FrequencyTableGetLowOn(int Symbol, FrequencyTable *ReceivedTable);
int FrequencyTableGetHighOn(int Symbol, FrequencyTable *ReceivedTable);

#endif
