#include "BitOutputStream.h"

//#####################################################################################################
BitOutputStream* BitOutputStreamCreate(char *OutputFileName){
    BitOutputStream *NewBitOutputStream = (BitOutputStream*) malloc(sizeof(BitOutputStream));

    NewBitOutputStream->FinalDataFile = fopen(OutputFileName, "wb+");
    if (NewBitOutputStream->FinalDataFile == NULL){
        printf("\nCan not open '%s' file on 'BitOutputStreamCreate'!", OutputFileName);
        exit(4);
    }

    NewBitOutputStream->CurrentByte = 0;
    NewBitOutputStream->ManyBitsInCurrentByte = 0;
    NewBitOutputStream->ManyReadyBytes = 0;
    NewBitOutputStream->EndStream = false;

    return NewBitOutputStream;
}
//#####################################################################################################

//------------------------------------BEGIN OF OPERATIONAL FUNCTIONS-----------------------------------

//#####################################################################################################
void BitOutputStreamWriteBit(BitOutputStream *MyBitOutputStream, int ReceivedBit){

    if ((ReceivedBit != 0) && (ReceivedBit != 1)){
        printf("\nInvalid bit value '%d' found on 'BitOutputStreamWriteBit'!", ReceivedBit);
        exit(4);
    }

    MyBitOutputStream->CurrentByte = (MyBitOutputStream->CurrentByte << 1) | ReceivedBit;
    MyBitOutputStream->ManyBitsInCurrentByte++;

    if (MyBitOutputStream->ManyBitsInCurrentByte == 8){

        MyBitOutputStream->ReadyBytes[MyBitOutputStream->ManyReadyBytes] = MyBitOutputStream->CurrentByte;
        MyBitOutputStream->CurrentByte = 0;
        MyBitOutputStream->ManyBitsInCurrentByte = 0;
        MyBitOutputStream->ManyReadyBytes++;

        if ((MyBitOutputStream->ManyReadyBytes == 250000) || (MyBitOutputStream->EndStream)){
            fwrite(MyBitOutputStream->ReadyBytes, sizeof(char), MyBitOutputStream->ManyReadyBytes, MyBitOutputStream->FinalDataFile);
            MyBitOutputStream->ManyReadyBytes = 0;
        }
    }
}
//#####################################################################################################

//#####################################################################################################
void BitOutputStreamCloseStream(BitOutputStream *MyBitOutputStream){

    if (MyBitOutputStream->ManyBitsInCurrentByte == 7){
        MyBitOutputStream->EndStream = true;
    }
    BitOutputStreamWriteBit(MyBitOutputStream, 1);
    while (MyBitOutputStream->ManyBitsInCurrentByte != 0){
        if (MyBitOutputStream->ManyBitsInCurrentByte == 7){
            MyBitOutputStream->EndStream = true;
        }
        BitOutputStreamWriteBit(MyBitOutputStream, 0);
    }
    fclose(MyBitOutputStream->FinalDataFile);
}
//#####################################################################################################

//-------------------------------------END OF OPERATIONAL FUNCTIONS------------------------------------
