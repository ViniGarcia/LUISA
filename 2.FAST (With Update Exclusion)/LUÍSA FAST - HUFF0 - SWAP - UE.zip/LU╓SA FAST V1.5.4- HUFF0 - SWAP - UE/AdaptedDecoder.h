#if !defined(ADAPTEDDECODER_H)
#define ADAPTEDDECODER_H

#include "Decoder.h"

//CONSTRUCTOR
Decoder* AdaptedDecoderCreate(char *InputFileName);

//OPERATIONAL
void AdaptedDecoderUpdateLowHigh(Decoder *MyDecoder, long long FrequencyTableTotal, long long FrequencyTableLow, long long FrequencyTableHigh,  int Symbol);

#endif
