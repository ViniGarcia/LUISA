#include "FrequencyTable.h"

//#####################################################################################################
FrequencyTable* FrequencyTableCreate(int ContextsAmount){
    int i;
    FrequencyTable *NewFrequencyTable;

    NewFrequencyTable = (FrequencyTable*) malloc(sizeof(FrequencyTable));
    NewFrequencyTable->Frequences = (int*) malloc((256*(ContextsAmount+1)+1)*sizeof(int));
    for (i = 0; i < (256*(ContextsAmount+1)+1); i++)
        NewFrequencyTable->Frequences[i] = 1;

    NewFrequencyTable->Total = (256*(ContextsAmount+1)+1);
    NewFrequencyTable->Size = (256*(ContextsAmount+1)+1);

    return NewFrequencyTable;
}
//#####################################################################################################


//-------------------------------------BEGIN OF CHECKING FUNCTIONS-------------------------------------

//#####################################################################################################
int FrequencyTableGetSymbolLimit(FrequencyTable *ReceivedTable){

    return ReceivedTable->Size;
}
//#####################################################################################################

//#####################################################################################################
void FrequencyTableCheckSum(long X, long Y){
    long Z;

    Z = X + Y;
    if ((Y > 0 && Z < X) || (Y < 0 && Z > X)){
        printf("Overflow detected on 'FrequencyTableCheckSum'!");
        exit(1);
    }
}
//#####################################################################################################

//#####################################################################################################
void FrequencyTableCheckSymbolInRange(int Symbol, FrequencyTable *ReceivedTable){

    if (ReceivedTable == NULL){
        printf("\nFrequency table is NULL on 'FrequencyTableCheckSymbolInRange'!");
        exit(1);
    }
    if ((Symbol < 0) || (Symbol >= FrequencyTableGetSymbolLimit(ReceivedTable))){
        printf("\nIllegal symbol '%d' received in 'FrequencyTableCheckSymbolInRange' (range: 0 ~ %d)!", Symbol, ReceivedTable->Size);
        exit(1);
    }
}
//#####################################################################################################

//--------------------------------------END OF CHECKING FUNCTIONS--------------------------------------


//------------------------------------BEGIN OF MANAGEMENT FUNCTIONS------------------------------------

//#####################################################################################################
int FrequencyTableAccumulateFrequencyTill(int Symbol, FrequencyTable *ReceivedTable){
    int i, Accumulated;

    Accumulated = 0;
    for (i = 0; i < Symbol; i++)
        Accumulated += ReceivedTable->Frequences[i];

    return Accumulated;
}
//#####################################################################################################

//-------------------------------------END OF MANAGEMENT FUNCTIONS-------------------------------------


//------------------------------------BEGIN OF OPERATIONAL FUNCTIONS------------------------------------

//######################################################################################################
void FrequencyTableInsertOn(int Symbol, FrequencyTable *ReceivedTable){
    FrequencyTableCheckSymbolInRange(Symbol, ReceivedTable);
    ReceivedTable->Frequences[Symbol]++;
    ReceivedTable->Total++;
}
//######################################################################################################

//######################################################################################################
int FrequencyTableGetTotal(FrequencyTable *ReceivedTable){

    if (ReceivedTable == NULL){
        printf("\nFrequency table is NULL on 'FrequencyTableGetTotal'!");
        exit(1);
    }
    if (ReceivedTable->Total < 0){
        printf("\nIllegal value to frequency table received in 'FrequencyTableGetTotal'!");
        exit(1);
    }
    return ReceivedTable->Total;
}
//######################################################################################################

//######################################################################################################
int FrequencyTableGetFrequency(int Symbol, FrequencyTable *ReceivedTable){

    FrequencyTableCheckSymbolInRange(Symbol, ReceivedTable);
    if (ReceivedTable->Frequences[Symbol] < 0){
        printf("\nIllegal value to symbol '%d' frequency received in 'FrequencyTableGetFrequency'!", Symbol);
        exit(1);
    }
    return ReceivedTable->Frequences[Symbol];
}
//######################################################################################################

//######################################################################################################
int FrequencyTableGetLowOn(int Symbol, FrequencyTable *ReceivedTable){
    int Low, High, Total;

    FrequencyTableCheckSymbolInRange(Symbol, ReceivedTable);
    Low = FrequencyTableAccumulateFrequencyTill(Symbol, ReceivedTable);
    High = Low + ReceivedTable->Frequences[Symbol];
    Total = ReceivedTable->Total;

    if ((0 > Low) || (Low > High) || (High > Total)){
        printf("\nIllegal value to low or high on table received in 'FrequencyTableGetLowOn'!");
        exit(1);
    }
    return Low;
}
//######################################################################################################

//######################################################################################################
int FrequencyTableGetHighOn(int Symbol, FrequencyTable *ReceivedTable){
    int Low, High, Total;

    FrequencyTableCheckSymbolInRange(Symbol, ReceivedTable);
    Low = FrequencyTableAccumulateFrequencyTill(Symbol, ReceivedTable);
    High = Low + ReceivedTable->Frequences[Symbol];
    Total = ReceivedTable->Total;

     if ((0 > Low) || (Low > High) || (High > Total)){
        printf("\nIllegal value to low or high on table received in 'FrequencyTableGetHighOn'!");
        exit(1);
    }
    return High;
}
//######################################################################################################

//-------------------------------------END OF OPERATIONAL FUNCTIONS-------------------------------------
