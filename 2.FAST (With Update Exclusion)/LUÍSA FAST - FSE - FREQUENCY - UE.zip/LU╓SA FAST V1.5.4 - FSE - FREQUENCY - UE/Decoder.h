#if !defined(DECODER_H)
#define DECODER_H

#include "BitInputStream.h"
#include "Encoder.h"

typedef struct Decoder {
    long long ManyBitsForLowHigh;
    long long FullOneMask;
    long long MaxBitZeroFullOneMask;
    long long MaxBitOneMask;
    long long RightMaxBitOneMask;
    long long MaxRange;
    long long MinRange;
    long long MaxTotal;

    long long Low;
    long long High;

    long long Code;

    BitInputStream *MyBitInputStream;
} Decoder;

//PRIVATE CONSTRUCTOR (FOR ADAPTEDDECODER)
void DecoderInitiateConstant(Decoder *NewDecoder);
void DecoderResetLowHigh(Decoder *NewDecoder);
void DecoderStartCode(Decoder *NewDecoder);

//CONSTRUCTOR
Decoder* DecoderCreate(char *InputFileName);

//MANAGEMENT (FOR ADAPTEDDECODER)
int GetNextBit(Decoder *MyDecoder);
void DecoderUnderflowBitsReview(Decoder *MyDecoder);
void DecoderGetInput(Decoder *MyDecoder);

//OPERATIONAL
int DecoderGetByte(Decoder *MyDecoder, FrequencyTable *MyFrequencyTable);
void DecoderFinish(Decoder *MyDecoder);

#endif
