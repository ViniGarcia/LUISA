#if !defined(ADAPTEDENCODER_H)
#define ADAPTEDENCODER_H

#include "Encoder.h"

//OPERATIONAL
void AdaptedEncoderUpdateLowHigh(Encoder *MyEncoder, long long FrequencyTableTotal, long long FrequencyTableLow, long long FrequencyTableHigh, int Symbol);

#endif
