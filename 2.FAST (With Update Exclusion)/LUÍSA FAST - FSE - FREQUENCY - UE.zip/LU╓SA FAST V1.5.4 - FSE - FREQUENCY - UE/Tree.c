#include "Tree.h"
#define ERROR 2

TreeNode Mock;

Tree* TCreate(int Orders){
    //�RVORE ->
    Tree *NewContextsTree;
    //VARI�VEIS DE CONTROLE ->
    int Index;
    TreeNode *NewNode;

    //====================== ETAPA DE INICIALIZA��O DA �RVORE ======================
    NewContextsTree = (Tree*) malloc(sizeof(Tree));
    NewContextsTree->Orders = Orders;
    NewContextsTree->ContextOrder = Orders;
    NewContextsTree->Context = TNDictionary();
    //==============================================================================

    //====================== ETAPA DE INICIALIZA��O DE CONTEXTO =====================
    NewContextsTree->Context = NewContextsTree->Context->Children[0].SymbolOwner;
    for (Index = 1; Index < NewContextsTree->Orders; Index++){
        NewNode = TNInsert(0, NewContextsTree->Context);
        NewNode->SuffixLink = NewContextsTree->Context;
        NewContextsTree->Context = NewNode;
    }
    //==============================================================================

    //======================= ETAPA DE INICIALIZA��O DE MOCK ======================
    Mock.ChildrenAmount = 0;
    //==============================================================================

    return NewContextsTree;
}

short int TFindBySymbol(short int Symbol, Tree *ContextsTree){
    //VARI�VEIS DE CONTROLE ->
    int OrdersIndex, ExclusionIndex;
    TreeNode *Index, *NodeIndex;
    TreeNode *SuffixInsert = &Mock;
    TreeNode *NodeExclusion = &Mock;
    //VARI�VEIS DE DADOS ->
    int SymbolPosition, Key;

    //====================== ETAPA DE PROCURA DA CHAVE =====================
    for (OrdersIndex = 0, NodeIndex = ContextsTree->Context; NodeIndex->Children == NULL; NodeIndex = NodeIndex->SuffixLink, OrdersIndex++);
    for (; NodeIndex->Children[Symbol].SymbolOwner == NULL; NodeIndex = NodeIndex->SuffixLink, OrdersIndex++){
        NodeExclusion = NodeIndex;
    }

    SymbolPosition = NodeIndex->Children[Symbol].SymbolOwner->Position;
    Key = SymbolPosition;
    if (NodeExclusion->ChildrenAmount > 0){
        Key += NodeExclusion->ChildrenAmount;
        for (ExclusionIndex = 0; ExclusionIndex < SymbolPosition; ExclusionIndex++){
            if (NodeExclusion->Children[NodeIndex->Children[ExclusionIndex].PositionOwner->Symbol].SymbolOwner != NULL){
                Key--;
            }
        }
    }
    //=======================================================================

    //=================== ETAPA DE ATUALIZA��O DA �RVORE ====================
    if (MMAllocation(OrdersIndex)){
        for (Index = ContextsTree->Context; Index != NodeIndex; Index = Index->SuffixLink){
            SuffixInsert->SuffixLink = TNInsert(Symbol, Index);
            SuffixInsert = SuffixInsert->SuffixLink;
        }
        ContextsTree->Context = ContextsTree->Context->SuffixLink->Children[Symbol].SymbolOwner;
    }
    else{
        if ((ContextsTree->ContextOrder == ContextsTree->Orders) && (NodeIndex == ContextsTree->Context)){
            ContextsTree->Context = ContextsTree->Context->SuffixLink->Children[Symbol].SymbolOwner;
        }
        else{
            ContextsTree->Context = NodeIndex->Children[Symbol].SymbolOwner;
            ContextsTree->ContextOrder -= (OrdersIndex - 1);
        }
    }
    SuffixInsert->SuffixLink = TNUpdate(SymbolPosition, NodeIndex);
    //=======================================================================

    return Key;
}

short int TFindByPosition(short int Position, Tree *ContextsTree){
    //VARI�VEIS DE CONTROLE ->
    int OrdersIndex, ExclusionIndex, MatchNodes;
    TreeNode *Index, *NodeIndex;
    TreeNode *SuffixInsert = &Mock;
    TreeNode *NodeExclusion = &Mock;
    //VARI�VEIS DE DADOS ->
    short int Symbol;

    //===================== ETAPA DE PROCURA DO S�MBOLO =====================
    for (OrdersIndex = 0, NodeIndex = ContextsTree->Context; NodeIndex->ChildrenAmount <= Position; NodeIndex = NodeIndex->SuffixLink,OrdersIndex++){
        NodeExclusion = NodeIndex;
    }

    if (NodeExclusion->ChildrenAmount > 0){
        Position -= NodeExclusion->ChildrenAmount;
        MatchNodes = Position;
        for (ExclusionIndex = 0; MatchNodes != -1; ExclusionIndex++){
            if (NodeExclusion->Children[NodeIndex->Children[ExclusionIndex].PositionOwner->Symbol].SymbolOwner != NULL){
                Position++;
            }
            else{
                MatchNodes--;
            }
        }
    }
    Symbol = NodeIndex->Children[Position].PositionOwner->Symbol;
    //=======================================================================

    //=================== ETAPA DE ATUALIZA��O DA �RVORE ====================
    if (MMAllocation(OrdersIndex)){
        for (Index = ContextsTree->Context; Index != NodeIndex; Index = Index->SuffixLink){
            SuffixInsert->SuffixLink = TNInsert(Symbol, Index);
            SuffixInsert = SuffixInsert->SuffixLink;
        }
        ContextsTree->Context = ContextsTree->Context->SuffixLink->Children[Symbol].SymbolOwner;
    }
    else{
        if ((ContextsTree->ContextOrder == ContextsTree->Orders) && (NodeIndex == ContextsTree->Context)){
            ContextsTree->Context = ContextsTree->Context->SuffixLink->Children[Symbol].SymbolOwner;
        }
        else{
            ContextsTree->Context = NodeIndex->Children[Symbol].SymbolOwner;
            ContextsTree->ContextOrder -= (OrdersIndex - 1);
        }
    }
    SuffixInsert->SuffixLink = TNUpdate(Position, NodeIndex);
    //=======================================================================

    return Symbol;
}
