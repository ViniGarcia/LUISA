#include "LuisaDecoder.h"
#define ERROR 4
#define BLOCKLENGHT 125000

void LDExecute(char *InputFileName, char *OutputFileName){
    //VARI�VEIS DE EXECU��O ->
    unsigned char WriteBytes[BLOCKLENGHT];
    unsigned char ReadBytes[BLOCKLENGHT];
    int Amount, Index;
    //DECODIFICADOR ->
    LuisaDecoder *MainDecoder;

    //==================== ETAPA DE CRIA��O DO DECODIFICADOR ====================
    MainDecoder = (LuisaDecoder*) malloc(sizeof(LuisaDecoder));
    MainDecoder->InputFile = fopen(InputFileName, "rb");
    MainDecoder->OutputFile = fopen(OutputFileName, "wb+");
    MainDecoder->ContextsTree = TCreate(fgetc(MainDecoder->InputFile));
    //============================================================================

    //==================== ETAPA DE EXECU��O DA DECODIFICA��O ====================
    for (Amount = C8BBlockDecompress(ReadBytes, MainDecoder->InputFile); Amount != -1; Amount = C8BBlockDecompress(ReadBytes, MainDecoder->InputFile)){
        for (Index = 0; Index < Amount; Index++){
            WriteBytes[Index] = TFindByPosition((unsigned short) ReadBytes[Index], MainDecoder->ContextsTree);
        }
        fwrite(WriteBytes, sizeof(char), Amount, MainDecoder->OutputFile);
    }
    //============================================================================

    //==================== ETAPA DE CONCLUS�O DA DECODIFICA��O ===================
    fclose(MainDecoder->InputFile);
    fclose(MainDecoder->OutputFile);
    //============================================================================
}
