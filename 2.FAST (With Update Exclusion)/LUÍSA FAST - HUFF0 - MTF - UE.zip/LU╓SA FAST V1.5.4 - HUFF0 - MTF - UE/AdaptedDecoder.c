#include "AdaptedDecoder.h"

//#####################################################################################################
Decoder* AdaptedDecoderCreate(char *InputFileName){
    Decoder *NewDecoder = (Decoder*) malloc(sizeof(Decoder));

    NewDecoder->MyBitInputStream = BitInputStreamCreate(InputFileName);
    DecoderInitiateConstant(NewDecoder);
    DecoderResetLowHigh(NewDecoder);

    return NewDecoder;
}
//#####################################################################################################

//------------------------------------BEGIN OF OPERATIONAL FUNCTIONS-----------------------------------

//#####################################################################################################
void AdaptedDecoderUpdateLowHigh(Decoder *MyDecoder, long long FrequencyTableTotal, long long FrequencyTableLow, long long FrequencyTableHigh,  int Symbol){
    long long Range = MyDecoder->High - MyDecoder->Low + 1;
    long long LastLow = MyDecoder->Low;

    if ((MyDecoder->Low >= MyDecoder->High) || ((MyDecoder->Low & MyDecoder->FullOneMask) != MyDecoder->Low) || ((MyDecoder->High & MyDecoder->FullOneMask) != MyDecoder->High)){
        printf("\nLow (%lld) or High (%lld) value out of normal range checked on 'DecoderUpdateLowHigh'!");
        exit(2);
    }
    if ((Range < MyDecoder->MinRange) || (Range > MyDecoder->MaxRange)){
        printf("\nCalculated range out of expected ranges checked on 'DecoderUpdateLowHigh'!");
        exit(2);
    }

    if (FrequencyTableLow == FrequencyTableHigh){
        printf("\nSymbol has zero frequency checked on 'DecoderUpdateLowHigh'!");
        exit(2);
    }
    if (FrequencyTableTotal > MyDecoder->MaxTotal){
        printf("\nSymbol amount overflow checked on 'DecoderUpdateLowHigh'!");
        exit(2);
    }

    MyDecoder->Low = LastLow + FrequencyTableLow  * Range / FrequencyTableTotal;
    MyDecoder->High = LastLow + FrequencyTableHigh * Range / FrequencyTableTotal - 1;

    while (((MyDecoder->Low ^ MyDecoder->High) & MyDecoder->MaxBitOneMask) == 0) {

        DecoderGetInput(MyDecoder);

		MyDecoder->Low = (MyDecoder->Low << 1) & MyDecoder->FullOneMask;
		MyDecoder->High = ((MyDecoder->High << 1) & MyDecoder->FullOneMask) | 1;
    }

    while ((MyDecoder->Low & ~MyDecoder->High & MyDecoder->RightMaxBitOneMask) != 0) {

		DecoderUnderflowBitsReview(MyDecoder);

		MyDecoder->Low = (MyDecoder->Low << 1) & (MyDecoder->MaxBitZeroFullOneMask);
		MyDecoder->High = ((MyDecoder->High << 1) & (MyDecoder->MaxBitZeroFullOneMask)) | MyDecoder->MaxBitOneMask | 1;
    }
}
//#####################################################################################################

//-------------------------------------END OF OPERATIONAL FUNCTIONS------------------------------------
