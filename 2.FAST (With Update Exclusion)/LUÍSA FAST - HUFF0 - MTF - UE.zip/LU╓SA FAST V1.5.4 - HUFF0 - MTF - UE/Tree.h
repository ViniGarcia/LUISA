#ifndef TREE_H
#define TREE_H

#include "TreeComponents.h"

typedef struct Tree{
    int Orders;
    int ContextOrder;
    TreeNode *Context;
} Tree;

Tree* TCreate(int Orders);
short int TFindBySymbolStart(short int Symbol, Tree *ContextsTree);
short int TFindBySymbol(short int Symbol, Tree *ContextsTree);
short int TFindByPosition(short int Position, Tree *ContextsTree);

#endif
