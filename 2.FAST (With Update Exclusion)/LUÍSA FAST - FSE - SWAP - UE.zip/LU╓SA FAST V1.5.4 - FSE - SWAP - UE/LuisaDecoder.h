#ifndef LUISADECODER_H
#define LUISADECODER_H

#include "Tree.h"
#include "Decoder.h"
#include "FSE/Compressor8Bits.h"

typedef struct LuisaDecoder{
    Tree *ContextsTree;
    FILE *InputFile;
    FILE *OutputFile;
} LuisaDecoder;

void LDExecute(char *InputFileName, char *OutputFileName);

#endif
