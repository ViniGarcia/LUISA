#ifndef TREECOMPONENTS_H
#define TREECOMPONENTS_H

#include <stdlib.h>
#include <stdio.h>

typedef struct ChildrenNode ChildrenNode;
typedef struct TreeNode TreeNode;

struct ChildrenNode{
    TreeNode *PositionOwner;
    TreeNode *SymbolOwner;
};

struct TreeNode{
    unsigned char Symbol;
    unsigned char Position;
    short int ChildrenAmount;
    ChildrenNode *Children;
    TreeNode *SuffixLink;
};

#include "MemoryManager.h"

TreeNode* TNDictionary();
TreeNode* TNInsert(short int Symbol, TreeNode *Node);
TreeNode* TNUpdate(short int Position, TreeNode *Node);

#endif
