#include "MemoryManager.h"
#define ERROR 3

ChildrenNode *AllocatedChildrenNodes;
unsigned long long TotalChildrenNodes = 50000000, UsedChildrenNodes = 7424;
TreeNode *AllocatedTreeNodes;
unsigned long long TotalTreeNodes = 50000000, UsedTreeNodes = 99;

bool MMAllocation(int Amount){
    if ((TotalTreeNodes + (100 - UsedChildrenNodes) >= Amount) &&
    (TotalChildrenNodes + (7680 - UsedChildrenNodes) >= Amount * 256)){
        return true;
    }
    return false;
}

TreeNode* MMGetTreeNode(){

    if (UsedTreeNodes == 99){
        AllocatedTreeNodes = (TreeNode*) malloc(100 * sizeof(TreeNode));
        UsedTreeNodes = 0;
        TotalTreeNodes -= 100;
        return &AllocatedTreeNodes[0];
    }

    UsedTreeNodes++;
    return &AllocatedTreeNodes[UsedTreeNodes];
}

ChildrenNode* MMGetChildrenNode(){

    if (UsedChildrenNodes == 7424){
        AllocatedChildrenNodes = (ChildrenNode*) calloc(7680, sizeof(ChildrenNode));
        UsedChildrenNodes = 0;
        TotalChildrenNodes -= 7680;
        return &AllocatedChildrenNodes[0];
    }

    UsedChildrenNodes += 256;
    return &AllocatedChildrenNodes[UsedChildrenNodes];
}
