#include "AdaptedEncoder.h"


//------------------------------------BEGIN OF OPERATIONAL FUNCTIONS-----------------------------------

//#####################################################################################################
void AdaptedEncoderUpdateLowHigh(Encoder *MyEncoder, long long FrequencyTableTotal, long long FrequencyTableLow, long long FrequencyTableHigh, int Symbol){
    long long Range = MyEncoder->High - MyEncoder->Low + 1;
    long long LastLow = MyEncoder->Low;

    if ((MyEncoder->Low >= MyEncoder->High) || ((MyEncoder->Low & MyEncoder->FullOneMask) != MyEncoder->Low) || ((MyEncoder->High & MyEncoder->FullOneMask) != MyEncoder->High)){
        printf("\nLow (%lld) or High (%lld) value out of normal range checked on 'EncoderUpdateLowHigh'!");
        exit(2);
    }
    if ((Range < MyEncoder->MinRange) || (Range > MyEncoder->MaxRange)){
        printf("\nCalculated range out of expected ranges checked on 'EncoderUpdateLowHigh'!");
        exit(2);
    }

    if (FrequencyTableLow == FrequencyTableHigh){
        printf("\nSymbol has zero frequency checked on 'EncoderUpdateLowHigh'!");
        exit(2);
    }
    if (FrequencyTableTotal > MyEncoder->MaxTotal){
        printf("\nSymbol amount overflow checked on 'EncoderUpdateLowHigh'!");
        exit(2);
    }

    MyEncoder->Low = LastLow + FrequencyTableLow  * Range / FrequencyTableTotal;
    MyEncoder->High = LastLow + FrequencyTableHigh * Range / FrequencyTableTotal - 1;

    while (((MyEncoder->Low ^ MyEncoder->High) & MyEncoder->MaxBitOneMask) == 0) {

        EncoderSetOutput(MyEncoder);

		MyEncoder->Low = (MyEncoder->Low << 1) & MyEncoder->FullOneMask;
		MyEncoder->High = ((MyEncoder->High << 1) & MyEncoder->FullOneMask) | 1;
    }

    while ((MyEncoder->Low & ~MyEncoder->High & MyEncoder->RightMaxBitOneMask) != 0) {

		EncoderUnderflowBitsReview(MyEncoder);

		MyEncoder->Low = (MyEncoder->Low << 1) & (MyEncoder->MaxBitZeroFullOneMask);
		MyEncoder->High = ((MyEncoder->High << 1) & (MyEncoder->MaxBitZeroFullOneMask)) | MyEncoder->MaxBitOneMask | 1;
    }
}
//#####################################################################################################

//-------------------------------------END OF OPERATIONAL FUNCTIONS------------------------------------
