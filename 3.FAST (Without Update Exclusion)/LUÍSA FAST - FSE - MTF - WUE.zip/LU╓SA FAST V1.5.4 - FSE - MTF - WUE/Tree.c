#include "Tree.h"
#define ERROR 2

TreeNode Mock;

Tree* TCreate(int Orders){
    //�RVORE ->
    Tree *NewContextsTree;
    //VARI�VEIS DE CONTROLE ->
    int Index;
    TreeNode *NewNode;

    //====================== ETAPA DE INICIALIZA��O DA �RVORE ======================
    NewContextsTree = (Tree*) malloc(sizeof(Tree));
    NewContextsTree->Orders = Orders;
    NewContextsTree->ContextOrder = Orders;
    NewContextsTree->Context = TNDictionary();
    //==============================================================================

    //====================== ETAPA DE INICIALIZA��O DE CONTEXTO =====================
    NewContextsTree->Context = NewContextsTree->Context->Children[0].SymbolOwner;
    for (Index = 1; Index < NewContextsTree->Orders; Index++){
        NewNode = TNCompressionInsert(0, NewContextsTree->Context);
        NewNode->SuffixLink = NewContextsTree->Context;
        NewContextsTree->Context = NewNode;
    }
    //==============================================================================

    //======================= ETAPA DE INICIALIZA��O DE MOCK ======================
    Mock.ChildrenAmount = 0;
    //==============================================================================

    return NewContextsTree;
}

short int TFindBySymbol(short int Symbol, Tree *ContextsTree){
    //VARI�VEIS DE CONTROLE ->
    int OrdersIndex;
    TreeNode *Index, *NodeIndex;
    TreeNode *SuffixInsert = &Mock;
    TreeNode *LevelSkip = &Mock;
    //VARI�VEIS DE DADOS ->
    int AccumulatedOrders, SymbolPosition;

    //====================== ETAPA DE PROCURA DA CHAVE =====================
    AccumulatedOrders = 0;
    for (OrdersIndex = 0, NodeIndex = ContextsTree->Context; NodeIndex->Children == NULL; NodeIndex = NodeIndex->SuffixLink, OrdersIndex++);
    for (; NodeIndex->Children[Symbol].SymbolOwner == NULL; NodeIndex = NodeIndex->SuffixLink, OrdersIndex++){
        if (LevelSkip->ChildrenAmount != NodeIndex->ChildrenAmount){
            AccumulatedOrders += NodeIndex->ChildrenAmount;
            LevelSkip = NodeIndex;
        }
    }
    SymbolPosition = NodeIndex->Children[Symbol].SymbolOwner->Data;
    //=======================================================================

    //=================== ETAPA DE ATUALIZA��O DA �RVORE ====================
    if (MMAllocation(OrdersIndex)){
        for (Index = ContextsTree->Context; Index != NodeIndex; Index = Index->SuffixLink){
            SuffixInsert->SuffixLink = TNCompressionInsert(Symbol, Index);
            SuffixInsert = SuffixInsert->SuffixLink;
        }
        ContextsTree->Context = ContextsTree->Context->SuffixLink->Children[Symbol].SymbolOwner;
    }
    else{
        if ((ContextsTree->ContextOrder == ContextsTree->Orders) && (NodeIndex == ContextsTree->Context)){
            ContextsTree->Context = ContextsTree->Context->SuffixLink->Children[Symbol].SymbolOwner;
        }
        else{
            ContextsTree->Context = NodeIndex->Children[Symbol].SymbolOwner;
            ContextsTree->ContextOrder -= (OrdersIndex - 1);
        }
    }
    SuffixInsert->SuffixLink = TNCompressionUpdate(SymbolPosition, NodeIndex);
    //=======================================================================

    return AccumulatedOrders + SymbolPosition;
}

short int TFindByPosition(short int Position, Tree *ContextsTree){
    //VARI�VEIS DE CONTROLE ->
    int OrdersIndex;
    TreeNode *Index, *NodeIndex;
    TreeNode *SuffixInsert = &Mock;
    TreeNode *LevelSkip = &Mock;
    //VARI�VEIS DE DADOS ->
    short int Symbol;

    //===================== ETAPA DE PROCURA DO S�MBOLO =====================
    for (OrdersIndex = 0, NodeIndex = ContextsTree->Context; ((NodeIndex->ChildrenAmount <= Position) || (NodeIndex->ChildrenAmount == LevelSkip->ChildrenAmount)); NodeIndex = NodeIndex->SuffixLink,OrdersIndex++){
        if (LevelSkip->ChildrenAmount != NodeIndex->ChildrenAmount){
            Position -= NodeIndex->ChildrenAmount;
            LevelSkip = NodeIndex;
        }
    }
    Symbol = NodeIndex->Children[Position].PositionOwner->Data;
    //=======================================================================

    //=================== ETAPA DE ATUALIZA��O DA �RVORE ====================
    if (MMAllocation(OrdersIndex)){
        for (Index = ContextsTree->Context; Index != NodeIndex; Index = Index->SuffixLink){
            SuffixInsert->SuffixLink = TNDecompressionInsert(Symbol, Index);
            SuffixInsert = SuffixInsert->SuffixLink;
        }
        ContextsTree->Context = ContextsTree->Context->SuffixLink->Children[Symbol].SymbolOwner;
    }
    else{
        if ((ContextsTree->ContextOrder == ContextsTree->Orders) && (NodeIndex == ContextsTree->Context)){
            ContextsTree->Context = ContextsTree->Context->SuffixLink->Children[Symbol].SymbolOwner;
        }
        else{
            ContextsTree->Context = NodeIndex->Children[Symbol].SymbolOwner;
            ContextsTree->ContextOrder -= (OrdersIndex - 1);
        }
    }
    SuffixInsert->SuffixLink = TNDecompressionUpdate(Position, NodeIndex);
    //=======================================================================

    return Symbol;
}
