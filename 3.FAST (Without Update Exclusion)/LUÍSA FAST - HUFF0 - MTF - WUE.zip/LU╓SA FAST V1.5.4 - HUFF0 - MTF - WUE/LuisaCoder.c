#include "LuisaCoder.h"
#define ERROR 3
#define BLOCKLENGHT 125000

void LCExecute(char *InputFileName, char *OutputFileName, int OrdersAmount){
    //VARI�VEIS DE EXECU��O ->
    unsigned char ReadBytes[BLOCKLENGHT];
    unsigned char WriteBytes[BLOCKLENGHT + 6072];
    unsigned short Key;
    int Amount, Index, Record;
    //CODIFICADOR ->
    LuisaCoder *MainCoder;

    //===================== ETAPA DE CRIA��O DO CODIFICADOR =====================
    MainCoder = (LuisaCoder*) malloc(sizeof(LuisaCoder));
    MainCoder->ContextsTree = TCreate(OrdersAmount);
    MainCoder->InputFile = fopen(InputFileName, "rb");
    MainCoder->OutputFile = fopen(OutputFileName, "wb+");
    fputc(OrdersAmount, MainCoder->OutputFile);
    //============================================================================

    //===================== ETAPA DE EXECU��O DA CODIFICA��O =====================
    for (Amount = fread(ReadBytes, sizeof(char), BLOCKLENGHT, MainCoder->InputFile); Amount > 0; Amount = fread(ReadBytes, sizeof(char), BLOCKLENGHT, MainCoder->InputFile)){
        for (Index = 0, Record = 0; Index < Amount; Index++, Record++){
            // ==================== MECANISMO DE SEGURAN�A ====================
            if (Record > BLOCKLENGHT + 6069){
                C8BBlockCompress(WriteBytes, Record, MainCoder->OutputFile);
                Record = 0;
            }
            /*   ================================================================ */
            Key = TFindBySymbol(ReadBytes[Index], MainCoder->ContextsTree);
            if (Key < 255){
                WriteBytes[Record] = (unsigned char) Key;
            }
            else{
                WriteBytes[Record] = (unsigned char) 255;
                WriteBytes[Record+1] = (unsigned char) (Key / 255);
                WriteBytes[Record+2] = (unsigned char) (Key % 255);
                Record += 2;
            }
        }
        C8BBlockCompress(WriteBytes, Record, MainCoder->OutputFile);
    }
    C8BBlockEnd(MainCoder->OutputFile);
    //============================================================================

    //===================== ETAPA DE CONCLUS�O DA CODIFICA��O ====================
    fclose(MainCoder->InputFile);
    fclose(MainCoder->OutputFile);
    //============================================================================
}
