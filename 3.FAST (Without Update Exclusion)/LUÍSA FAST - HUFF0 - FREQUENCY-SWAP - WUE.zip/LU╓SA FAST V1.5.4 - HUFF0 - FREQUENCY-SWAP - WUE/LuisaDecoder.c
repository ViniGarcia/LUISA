#include "LuisaDecoder.h"
#define ERROR 4
#define BLOCKLENGHT 125000

void LDExecute(char *InputFileName, char *OutputFileName){
    //VARI�VEIS DE EXECU��O ->
    unsigned char WriteBytes[BLOCKLENGHT];
    unsigned char ReadBytes[BLOCKLENGHT + 6072];
    unsigned short Key;
    int Amount, Index, Record;
    //DECODIFICADOR ->
    LuisaDecoder *MainDecoder;

    //==================== ETAPA DE CRIA��O DO DECODIFICADOR ====================
    MainDecoder = (LuisaDecoder*) malloc(sizeof(LuisaDecoder));
    MainDecoder->InputFile = fopen(InputFileName, "rb");
    MainDecoder->OutputFile = fopen(OutputFileName, "wb+");
    MainDecoder->ContextsTree = TCreate(fgetc(MainDecoder->InputFile));
    //============================================================================

    //==================== ETAPA DE EXECU��O DA DECODIFICA��O ====================
    for (Amount = C8BBlockDecompress(ReadBytes, MainDecoder->InputFile); Amount != -1; Amount = C8BBlockDecompress(ReadBytes, MainDecoder->InputFile)){
        for (Index = 0, Record = 0; Index < Amount; Index++, Record++){
            if (ReadBytes[Index] != 255){
                Key = (unsigned short) ReadBytes[Index];
            }
            else{
                Key = (unsigned short) ((255 * ReadBytes[Index+1]) + ReadBytes[Index+2]);
                Index += 2;
            }
            WriteBytes[Record] = TFindByPosition(Key, MainDecoder->ContextsTree);
        }
        fwrite(WriteBytes, sizeof(char), Record, MainDecoder->OutputFile);
    }
    //============================================================================

    //==================== ETAPA DE CONCLUS�O DA DECODIFICA��O ===================
    fclose(MainDecoder->InputFile);
    fclose(MainDecoder->OutputFile);
    //============================================================================
}
