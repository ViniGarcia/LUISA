#ifndef LUISACODER_H
#define LUISACODER_H

#include "Tree.h"
#include "HUFF0/Compressor8Bits.h"

typedef struct LuisaCoder{
    Tree *ContextsTree;
    FILE *OutputFile;
    FILE *InputFile;
} LuisaCoder;

void LCExecute(char *InputFileName, char *OutputFileName, int OrdersAmount);

#endif
