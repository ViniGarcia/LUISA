#define ERROR (1)
#include "FrequencyNode.h"
#include <stdio.h>

FrequencyNode* FNCreate(int NodeSymbol){
    FrequencyNode *NewFrequencyNode;

    NewFrequencyNode = (FrequencyNode*) malloc(sizeof(FrequencyNode));
    NewFrequencyNode->NodeSymbol = NodeSymbol;
    NewFrequencyNode->NodePosition = -1;
    NewFrequencyNode->NodeChildren = (ControlNode*) malloc(sizeof(ControlNode));
    NewFrequencyNode->NodeChildren->NodeTotal = 0;
    NewFrequencyNode->NodeChildren->NodeFrequencyChildren = NULL;
    NewFrequencyNode->NodeChildren->NodeSearchChildren = NULL;
    NewFrequencyNode->NodeChildren->SearchPointerChildren = NULL;
    NewFrequencyNode->NodeControl = NULL;
    NewFrequencyNode->NodeSearcher = NULL;
    NewFrequencyNode->NodeLeftSibling = NULL;
    NewFrequencyNode->NodeRightSibling = NULL;

    return NewFrequencyNode;
}

FrequencyNode* FNInsert(FrequencyNode *InsertNode, ControlNode *NodeControl){
    FrequencyNode *Index;

    InsertNode->NodeControl = NodeControl;
    if (NodeControl->NodeFrequencyChildren == NULL){
        NodeControl->NodeFrequencyChildren = InsertNode;
        InsertNode->NodePosition = 1;
    }
    else{
        InsertNode->NodeRightSibling = NodeControl->NodeFrequencyChildren;
        NodeControl->NodeFrequencyChildren->NodeLeftSibling = InsertNode;
        NodeControl->NodeFrequencyChildren = InsertNode;
        InsertNode->NodePosition = 1;
        for (Index = InsertNode->NodeRightSibling; Index != NULL; Index = Index->NodeRightSibling){
            Index->NodePosition++;
        }
    }

    return NodeControl->NodeFrequencyChildren;
}

FrequencyNode* FNUpdate(FrequencyNode *UpdateNode){
    FrequencyNode *Index;

    if (UpdateNode->NodeLeftSibling == NULL){
        return UpdateNode;
    }
    else{
        for (Index = UpdateNode->NodeLeftSibling; Index != NULL; Index = Index->NodeLeftSibling){
            Index->NodePosition++;
        }
        Index = UpdateNode->NodeControl->NodeFrequencyChildren;
        UpdateNode->NodeLeftSibling->NodeRightSibling = UpdateNode->NodeRightSibling;
        if (UpdateNode->NodeRightSibling != NULL){
            UpdateNode->NodeRightSibling->NodeLeftSibling = UpdateNode->NodeLeftSibling;
        }
        UpdateNode->NodeLeftSibling = Index->NodeLeftSibling;
        UpdateNode->NodeRightSibling = Index;
        Index->NodeLeftSibling = UpdateNode;
        UpdateNode->NodeControl->NodeFrequencyChildren = UpdateNode;
        UpdateNode->NodePosition = 1;
    }

    return UpdateNode->NodeControl->NodeFrequencyChildren;
}
