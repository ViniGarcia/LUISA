#include "BitInputStream.h"

//#####################################################################################################
BitInputStream* BitInputStreamCreate(char *InputFileName){
    BitInputStream *NewBitInputStream = (BitInputStream*) malloc(sizeof(BitInputStream));

    NewBitInputStream->OriginalDataFile = fopen(InputFileName, "rb");
    if (NewBitInputStream->OriginalDataFile == NULL){
        printf("\nNo '%s' file found on 'BitInputStreamCreate'!", InputFileName);
        exit(3);
    }

    NewBitInputStream->NextReceivedBits = 0;
    NewBitInputStream->ManyBitsRemaining = 0;
    NewBitInputStream->ManyBytesRemaining = 0;
    NewBitInputStream->StreamEnd = false;

    return NewBitInputStream;
}
//#####################################################################################################


//------------------------------------BEGIN OF MANAGEMENT FUNCTIONS------------------------------------

//#####################################################################################################
int BitInputStreamReadBit(BitInputStream *MyBitInputStream){


    if ((MyBitInputStream->ManyBytesRemaining == 0) && (MyBitInputStream->ManyBitsRemaining == 0) && (!MyBitInputStream->StreamEnd)){
        MyBitInputStream->ManyBytesRemaining = fread(MyBitInputStream->ReadBytes, sizeof(char), 250000, MyBitInputStream->OriginalDataFile);
        if(MyBitInputStream->ManyBytesRemaining != 0){
            MyBitInputStream->LastByteBlockSize = MyBitInputStream->ManyBytesRemaining;
        }
        else{
            MyBitInputStream->ManyBytesRemaining = 1;
            MyBitInputStream->StreamEnd = true;
        }
    }

    if (MyBitInputStream->ManyBitsRemaining == 0){
        MyBitInputStream->NextReceivedBits = MyBitInputStream->ReadBytes[MyBitInputStream->LastByteBlockSize - MyBitInputStream->ManyBytesRemaining];

        MyBitInputStream->ManyBitsRemaining = 8;
        if (!MyBitInputStream->StreamEnd){
            MyBitInputStream->ManyBytesRemaining--;
        }
    }

    MyBitInputStream->ManyBitsRemaining--;
    return (MyBitInputStream->NextReceivedBits >> MyBitInputStream->ManyBitsRemaining) & 1;
}
//#####################################################################################################

//-------------------------------------END OF MANAGEMENT FUNCTIONS-------------------------------------

//------------------------------------BEGIN OF OPERATIONAL FUNCTIONS-----------------------------------

//#####################################################################################################
int BitInputStreamNextBit(BitInputStream *MyBitInputStream){
    int ReceivedBit;

    ReceivedBit = BitInputStreamReadBit(MyBitInputStream);

    if ((ReceivedBit != 0) && (ReceivedBit != 1) && (ReceivedBit != EOF)){
        printf("\nInvalid bit value '%d' found on 'BitInputStreamNextBit'!", ReceivedBit);
        exit(3);
    }

    if (ReceivedBit == EOF){
        printf("\nEnd of file value found on 'BitInputStreamNextBit'!");
        exit(3);
    }

    return ReceivedBit;
}
//#####################################################################################################

//#####################################################################################################
void BitInputStreamCloseStream(BitInputStream *MyBitInputStream){
    fclose(MyBitInputStream->OriginalDataFile);
}
//#####################################################################################################

//-------------------------------------END OF OPERATIONAL FUNCTIONS------------------------------------
