#define ERROR (4)
#include "LuisaTree.h"

LuisaTree* LTCreate(int ContextsAmount, int HashAmount){
    LuisaTree *NewLuisaTree;

    NewLuisaTree = (LuisaTree*) malloc(sizeof(LuisaTree));
    NewLuisaTree->ContextsAmount = ContextsAmount;
    NewLuisaTree->HashAmount = HashAmount;
    NewLuisaTree->ContextsTree = (ControlNode**) calloc((ContextsAmount + 1), sizeof(ControlNode*));
    if (HashAmount >= 0){
        NewLuisaTree->ContextsTree[0] = CNDictionary(true);
    }
    else{
        NewLuisaTree->ContextsTree[0] = CNDictionary(false);
    }

    return NewLuisaTree;
}

SearchNode* LTSearch(int SearchSymbol, int *SymbolLevel, LuisaTree *TreeControl){
    int Index;
    SearchNode *NodeIndex;

    NodeIndex = NULL;
    for (Index = TreeControl->ContextsAmount; TreeControl->ContextsTree[Index] == NULL; Index--);
    if (TreeControl->HashAmount >= 0){
        if (Index <= TreeControl->HashAmount){
            NodeIndex = CNAuthenticate(SearchSymbol, Index, SymbolLevel, TreeControl->ContextsTree);
        }
        else{
            NodeIndex = CNAuthenticate(SearchSymbol, TreeControl->HashAmount, SymbolLevel, TreeControl->ContextsTree);
        }
    }
    if (NodeIndex == NULL){
        for (; Index >= 0; Index--){
            if (Index > TreeControl->HashAmount){
                NodeIndex = CNSearch(false, SearchSymbol, NodeIndex, TreeControl->ContextsTree[Index]);
            }
            else{
                NodeIndex = CNSearch(true, SearchSymbol, NodeIndex, TreeControl->ContextsTree[Index]);
            }
            if ((NodeIndex != NULL) && (NodeIndex->NodeData->NodeSymbol == SearchSymbol)){
                SymbolLevel[0] = Index;
                return NodeIndex;
            }
            if (NodeIndex != NULL){
                NodeIndex = NodeIndex->NodeSuffix;
            }
        }
    }

    return NodeIndex;
}

void LTUpdate(int UpdateSymbol, SearchNode *NodeSymbol, LuisaTree *TreeControl){
    int Index;
    SearchNode *InsertedNode, *WaitingNode, *IndexNode;

    WaitingNode = NULL;
    for (Index = TreeControl->ContextsAmount; TreeControl->ContextsTree[Index] == NULL; Index--);
    for (; Index >= 0; Index--){
        if (NodeSymbol->NodeData->NodeControl == TreeControl->ContextsTree[Index]){
            break;
        }

        if (Index <= TreeControl->HashAmount){
            InsertedNode = CNInsert(true, UpdateSymbol, TreeControl->ContextsTree[Index]);
        }
        else{
            InsertedNode = CNInsert(false, UpdateSymbol, TreeControl->ContextsTree[Index]);
        }
        if (Index < TreeControl->ContextsAmount){
            TreeControl->ContextsTree[Index + 1] = InsertedNode->NodeData->NodeChildren;
        }
        if (WaitingNode != NULL){
            WaitingNode->NodeSuffix = InsertedNode;
        }
        WaitingNode = InsertedNode;
    }
    if (WaitingNode != NULL){
        WaitingNode->NodeSuffix = NodeSymbol;
    }

    for(IndexNode = NodeSymbol; Index >= 0; IndexNode = IndexNode->NodeSuffix, Index--){
        CNUpdate(IndexNode->NodeData);
        if (Index < TreeControl->ContextsAmount){
            TreeControl->ContextsTree[Index + 1] = IndexNode->NodeData->NodeChildren;
        }
    }
}
