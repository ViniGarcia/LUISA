#ifndef LUISACODING_H
#define LUISACODING_H

#include "LuisaTree.h"

LuisaCoder* LCCreate(char *InputFileName, char *OutputFileName, int ContextsAmount, int HashAmount);
void LCExecute(LuisaCoder *Coder);

#endif
