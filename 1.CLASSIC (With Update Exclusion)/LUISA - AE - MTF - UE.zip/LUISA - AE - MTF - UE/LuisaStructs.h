#ifndef LUISASTRUCTS_H
#define LUISASTRUCTS_H

#include "ControlNode.h"
#include "Encoder.h"
#include "Decoder.h"

typedef struct LuisaTree{
    int ContextsAmount;
    int HashAmount;
    ControlNode **ContextsTree;
} LuisaTree;

typedef struct LuisaCoder {
    FILE *InputFile;
    Encoder *ArithmeticEncoder;
    FrequencyTable *ArithmeticTable;
    LuisaTree *TreeControl;
} LuisaCoder;

typedef struct LuisaDecoder {
    FILE *OutputFile;
    Decoder *ArithmeticDecoder;
    FrequencyTable *ArithmeticTable;
    LuisaTree *TreeControl;
} LuisaDecoder;

#endif
