#ifndef CONTROLNODE_H
#define CONTROLNODE_H

#include <stdbool.h>
#include "SearchNode.h"

ControlNode* CNCreate();
ControlNode* CNDictionary(bool SearchPointerActivated);
SearchNode* CNSearch(bool SearchPointerActivated, int SearchSymbol, SearchNode *InitialNode, ControlNode *NodeControl);
SearchNode* CNInsert(bool SearchPointerActivated, int InsertSymbol, ControlNode *NodeControl);
SearchNode* CNAuthenticate(int SearchSymbol, int LowerSearchPointerLevel, int *SymbolLevel, ControlNode **NodeControls);
FrequencyNode* CNUpdate(FrequencyNode *UpdateNode);

#endif
