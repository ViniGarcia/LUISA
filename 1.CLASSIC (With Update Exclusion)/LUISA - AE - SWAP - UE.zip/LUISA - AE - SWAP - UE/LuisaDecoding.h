#ifndef LUISADECODING_H
#define LUISADECODING_H

#include <stdbool.h>
#include "LuisaTree.h"

LuisaDecoder* LDCreate(char *InputFileName, char *OutputFileName);
void LDExecute(LuisaDecoder *MainDecoder);

#endif
