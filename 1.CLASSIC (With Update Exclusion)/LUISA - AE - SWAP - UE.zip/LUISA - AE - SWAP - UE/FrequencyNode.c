#define ERROR (1)
#include "FrequencyNode.h"
#include <stdio.h>

FrequencyNode* FNCreate(int NodeSymbol){
    FrequencyNode *NewFrequencyNode;

    NewFrequencyNode = (FrequencyNode*) malloc(sizeof(FrequencyNode));
    NewFrequencyNode->NodeSymbol = NodeSymbol;
    NewFrequencyNode->NodePosition = -1;
    NewFrequencyNode->NodeChildren = (ControlNode*) malloc(sizeof(ControlNode));
    NewFrequencyNode->NodeChildren->NodeTotal = 0;
    NewFrequencyNode->NodeChildren->NodeFrequencyChildren = NULL;
    NewFrequencyNode->NodeChildren->NodeSearchChildren = NULL;
    NewFrequencyNode->NodeChildren->SearchPointerChildren = NULL;
    NewFrequencyNode->NodeControl = NULL;
    NewFrequencyNode->NodeSearcher = NULL;
    NewFrequencyNode->NodeLeftSibling = NULL;
    NewFrequencyNode->NodeRightSibling = NULL;

    return NewFrequencyNode;
}

FrequencyNode* FNInsert(FrequencyNode *InsertNode, ControlNode *NodeControl){
    FrequencyNode *Index, *SecondaryIndex;

    InsertNode->NodeControl = NodeControl;
    if (NodeControl->NodeFrequencyChildren == NULL){
        NodeControl->NodeFrequencyChildren = InsertNode;
        InsertNode->NodePosition = 1;
    }
    else{
        for (Index = NodeControl->NodeFrequencyChildren; Index != NULL; Index = Index->NodeRightSibling){
            SecondaryIndex = Index;
        }
        SecondaryIndex->NodeRightSibling = InsertNode;
        InsertNode->NodeLeftSibling = SecondaryIndex;
        InsertNode->NodePosition = SecondaryIndex->NodePosition + 1;
    }

    return NodeControl->NodeFrequencyChildren;
}

FrequencyNode* FNUpdate(FrequencyNode *UpdateNode){
    FrequencyNode *Index;

    if (UpdateNode->NodeLeftSibling == NULL){
        return UpdateNode;
    }
    else{
        Index = UpdateNode->NodeLeftSibling;
        if (Index->NodeLeftSibling != NULL){
            Index->NodeLeftSibling->NodeRightSibling = UpdateNode;
        }
        if (UpdateNode->NodeRightSibling != NULL){
            UpdateNode->NodeRightSibling->NodeLeftSibling = Index;
        }
        Index->NodeRightSibling = UpdateNode->NodeRightSibling;
        UpdateNode->NodeLeftSibling = Index->NodeLeftSibling;
        Index->NodeLeftSibling = UpdateNode;
        UpdateNode->NodeRightSibling = Index;
        if (UpdateNode->NodeLeftSibling == NULL){
            UpdateNode->NodeControl->NodeFrequencyChildren = UpdateNode;
        }
        Index->NodePosition++;
        UpdateNode->NodePosition--;
    }

    return UpdateNode->NodeControl->NodeFrequencyChildren;
}
