#include "SearchPointer.h"

SearchNode* SPInsert(SearchNode *InsertNode, ControlNode *NodeControl){

    if (NodeControl->SearchPointerChildren == NULL){
        NodeControl->SearchPointerChildren = (SearchNode**) calloc(256, sizeof(SearchNode*));
    }
    NodeControl->SearchPointerChildren[InsertNode->NodeData->NodeSymbol] = InsertNode;

    return InsertNode;
}

SearchNode* SPSearch(int SearchSymbol, ControlNode *NodeControl){
    int Index;

    if (NodeControl->SearchPointerChildren == NULL){
        return NULL;
    }
    if (NodeControl->SearchPointerChildren[SearchSymbol] != NULL){
        return NodeControl->SearchPointerChildren[SearchSymbol];
    }
    else{
        for (Index = SearchSymbol - 1; Index >= 0; Index--){
            if (NodeControl->SearchPointerChildren[Index] != NULL){
                return NodeControl->SearchPointerChildren[Index];
            }
        }
    }

    return NULL;
}

SearchNode* SPCheck(int SearchSymbol, ControlNode *NodeControl){
    if (NodeControl->SearchPointerChildren == NULL){
        return NULL;
    }
    return NodeControl->SearchPointerChildren[SearchSymbol];
}
