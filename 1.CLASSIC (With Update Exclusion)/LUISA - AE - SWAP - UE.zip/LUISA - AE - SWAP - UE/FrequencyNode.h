#ifndef FREQUENCYNODE_H
#define FREQUENCYNODE_H

#include "NodeStructs.h"

FrequencyNode* FNCreate(int NodeSymbol);
FrequencyNode* FNInsert(FrequencyNode *InsertNode, ControlNode *NodeControl);
FrequencyNode* FNUpdate(FrequencyNode *UpdateNode);

#endif
