#define ERROR (5)
#include "LuisaCoding.h"

int LCGetCode(int CodeSymbol, SearchNode **UpdateMatch, LuisaTree *TreeControl){
    int MatchLevel, UpdateFactor;
    SearchNode *MatchSymbol, *Index;

    MatchSymbol = LTSearch(CodeSymbol, &MatchLevel, TreeControl);
    UpdateFactor = 0;
    if ((MatchLevel < TreeControl->ContextsAmount) && (TreeControl->ContextsTree[MatchLevel+1] != NULL)){
        for (Index = TreeControl->ContextsTree[MatchLevel+1]->NodeSearchChildren;
            Index != NULL; Index = Index->NodeNext){
            if (Index->NodeSuffix->NodeData->NodePosition > MatchSymbol->NodeData->NodePosition){
                UpdateFactor++;
            }
        }
    }

    UpdateMatch[0] = MatchSymbol;

    return MatchSymbol->NodeData->NodePosition + UpdateFactor - 1;
}

void LCProcess(int CodeSymbol, LuisaCoder *MainCoder){
    int SymbolCode;
    SearchNode *UpdateMatch;

    SymbolCode = LCGetCode(CodeSymbol, &UpdateMatch, MainCoder->TreeControl);
    EncoderUpdateLowHigh(MainCoder->ArithmeticEncoder, MainCoder->ArithmeticTable, SymbolCode);
    FrequencyTableInsertOn(SymbolCode, MainCoder->ArithmeticTable);
    LTUpdate(CodeSymbol, UpdateMatch, MainCoder->TreeControl);
}

LuisaCoder* LCCreate(char *InputFileName, char *OutputFileName, int ContextsAmount, int HashAmount){
    LuisaCoder *NewCoder;

    NewCoder = (LuisaCoder*) malloc(sizeof(LuisaCoder));
    NewCoder->TreeControl = LTCreate(ContextsAmount, HashAmount);
    NewCoder->ArithmeticEncoder = EncoderCreate(OutputFileName);
    NewCoder->ArithmeticTable = FrequencyTableCreate();
    NewCoder->InputFile = fopen(InputFileName, "rb");
    if (NewCoder->InputFile == NULL){
        exit(ERROR);
    }
    if (HashAmount > -1){
        EncoderUpdateLowHigh(NewCoder->ArithmeticEncoder, NewCoder->ArithmeticTable, ContextsAmount);
        EncoderUpdateLowHigh(NewCoder->ArithmeticEncoder, NewCoder->ArithmeticTable, 2);
        EncoderUpdateLowHigh(NewCoder->ArithmeticEncoder, NewCoder->ArithmeticTable, HashAmount);
    }
    else{
        EncoderUpdateLowHigh(NewCoder->ArithmeticEncoder, NewCoder->ArithmeticTable, ContextsAmount);
        EncoderUpdateLowHigh(NewCoder->ArithmeticEncoder, NewCoder->ArithmeticTable, 1);
    }
    return NewCoder;
}

void LCExecute(LuisaCoder *MainCoder){
    unsigned char ReadBytes[500000];
    int Amount, Index;

    for (Amount = fread(ReadBytes, sizeof(char), 500000, MainCoder->InputFile); Amount > 0; Amount = fread(ReadBytes, sizeof(char), 500000, MainCoder->InputFile)){
        for (Index = 0; Index < Amount; Index++){
            LCProcess(ReadBytes[Index], MainCoder);
        }
    }
    EncoderUpdateLowHigh(MainCoder->ArithmeticEncoder, MainCoder->ArithmeticTable, 256);
    EncoderUpdateLowHigh(MainCoder->ArithmeticEncoder, MainCoder->ArithmeticTable, 256);
    EncoderFinish(MainCoder->ArithmeticEncoder);
    fclose(MainCoder->InputFile);
}
