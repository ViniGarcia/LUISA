#ifndef SEARCHNODE_H
#define SEARCHNODE_H

#include "FrequencyNode.h"
#include "SearchPointer.h"

SearchNode* SNCreate(FrequencyNode *NodeData);
SearchNode* SNInsert(SearchNode *InsertNode, ControlNode *NodeControl);
SearchNode* SNSearch(int SearchSymbol, SearchNode *InitialNode);

#endif
