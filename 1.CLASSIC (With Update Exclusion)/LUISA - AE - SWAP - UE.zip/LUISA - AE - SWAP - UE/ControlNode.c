#define ERROR (3)
#include "ControlNode.h"

ControlNode* CNCreate(){
    ControlNode *NewControlNode;

    NewControlNode = (ControlNode*) malloc(sizeof(ControlNode));
    NewControlNode->NodeTotal = 0;
    NewControlNode->NodeFrequencyChildren = NULL;
    NewControlNode->NodeSearchChildren = NULL;
    NewControlNode->SearchPointerChildren = NULL;

    return NewControlNode;
}

ControlNode* CNDictionary(bool SearchPointerActivated){
    int Index;
    ControlNode *NewDictionayNode;
    FrequencyNode *InsertFrequencyNode;
    SearchNode *InsertSearchNode;

    NewDictionayNode = CNCreate();
    for (Index = 0; Index < 256; Index++){
        InsertFrequencyNode = FNCreate(Index);
        FNInsert(InsertFrequencyNode, NewDictionayNode);
        InsertSearchNode = SNCreate(InsertFrequencyNode);
        SNInsert(InsertSearchNode, NewDictionayNode);
        if (SearchPointerActivated){
            SPInsert(InsertSearchNode, NewDictionayNode);
        }
        NewDictionayNode->NodeTotal++;
    }

    return NewDictionayNode;
}

SearchNode* CNSearch(bool SearchPointerActivated, int SearchSymbol, SearchNode *InitialNode, ControlNode *NodeControl){

    if (SearchPointerActivated){
        return SPCheck(SearchSymbol, NodeControl);
        /*Obs.: we used SPCheck because when the lower hash level found every level after will be hash too,
        if exits unconnected hash levels use SPSearch to get a suffix link.*/
    }
    else{
        if (InitialNode != NULL){
            return SNSearch(SearchSymbol, InitialNode);
        }
        else{
            return SNSearch(SearchSymbol, NodeControl->NodeSearchChildren);
        }
    }
}

SearchNode* CNInsert(bool SearchPointerActivated, int InsertSymbol, ControlNode *NodeControl){
    FrequencyNode *InsertFrequencyNode;
    SearchNode *InsertSearchNode;

    InsertFrequencyNode = FNCreate(InsertSymbol);
    FNInsert(InsertFrequencyNode, NodeControl);
    InsertSearchNode = SNCreate(InsertFrequencyNode);
    SNInsert(InsertSearchNode, NodeControl);
    if (SearchPointerActivated){
        SPInsert(InsertSearchNode, NodeControl);
    }
    NodeControl->NodeTotal++;

    return InsertSearchNode;
}

SearchNode* CNAuthenticate(int SearchSymbol, int LowerSearchPointerLevel, int *SymbolLevel, ControlNode **NodeControls){
    int Index;
    SearchNode *NodeIndex = NULL;

    if (SPCheck(SearchSymbol, NodeControls[LowerSearchPointerLevel]) != NULL){
        return NULL;
    }
    else{
        for (Index = LowerSearchPointerLevel - 1; NodeIndex == NULL; NodeIndex = SPCheck(SearchSymbol, NodeControls[Index]), Index--);
        SymbolLevel[0] = Index + 1;
        return NodeIndex;
    }
    /*Obs.: we used this function because when the lower hash level found every level after will be hash too, so, if the last
    hash level has the symbol, lower levels maybe has too, else, the first hash level with the symbol is the search level, it
    is a pre-search function.*/
}

FrequencyNode* CNUpdate(FrequencyNode *UpdateNode){
    return FNUpdate(UpdateNode);
}
