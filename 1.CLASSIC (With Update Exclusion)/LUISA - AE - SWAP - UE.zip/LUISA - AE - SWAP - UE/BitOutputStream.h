#if !defined(BITOUTPUTSTREAM_H)
#define BITOUTPUTSTREAM_H

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

typedef struct BitOutputStream {
    FILE *FinalDataFile;
    bool EndStream;
    unsigned char ReadyBytes[250000];
    int CurrentByte;
    int ManyBitsInCurrentByte;
    int ManyReadyBytes;
} BitOutputStream;

//CONSTRUCTOR
BitOutputStream* BitOutputStreamCreate(char *OutputFileName);

//OPERATIONAL
void BitOutputStreamWriteBit(BitOutputStream *MyBitOutputStream, int ReceivedBit);
void BitOutputStreamCloseStream(BitOutputStream *MyBitOutputStream);

#endif
