#include "Decoder.h"

//#####################################################################################################
void DecoderInitiateConstant(Decoder *NewDecoder){
    long long MaxLongLongValue = LLONG_MAX;

    NewDecoder->ManyBitsForLowHigh = 32;
    NewDecoder->FullOneMask = ((long long)1 << NewDecoder->ManyBitsForLowHigh)-1;
    NewDecoder->MaxBitZeroFullOneMask = (((long long)1 << (NewDecoder->ManyBitsForLowHigh-1))-1);
    NewDecoder->MaxBitOneMask = ((long long)1 << (NewDecoder->ManyBitsForLowHigh-1));
    NewDecoder->RightMaxBitOneMask = ((long long)1 << (NewDecoder->ManyBitsForLowHigh-2));
    NewDecoder->MaxRange = ((long long)1 << NewDecoder->ManyBitsForLowHigh);
    NewDecoder->MinRange = ((long long)1 << (NewDecoder->ManyBitsForLowHigh - 2))+2;

    if ((MaxLongLongValue/NewDecoder->MaxRange) < NewDecoder->MinRange)
        NewDecoder->MaxTotal = MaxLongLongValue/NewDecoder->MaxRange;
    else
        NewDecoder->MaxTotal = NewDecoder->MinRange;
}
//#####################################################################################################

//#####################################################################################################
void DecoderResetLowHigh(Decoder *NewDecoder){
    NewDecoder->Low = 0;
    NewDecoder->High = NewDecoder->FullOneMask;
}
//#####################################################################################################

//#####################################################################################################
void DecoderStartCode(Decoder *NewDecoder){
    int Index;

    NewDecoder->Code = 0;
    for(Index = 0; Index < NewDecoder->ManyBitsForLowHigh; Index++)
        NewDecoder->Code = (NewDecoder->Code << 1) | BitInputStreamNextBit(NewDecoder->MyBitInputStream);
}
//#####################################################################################################

//#####################################################################################################
Decoder* DecoderCreate(char *InputFileName){
    Decoder *NewDecoder = (Decoder*) malloc(sizeof(Decoder));

    NewDecoder->MyBitInputStream = BitInputStreamCreate(InputFileName);
    DecoderInitiateConstant(NewDecoder);
    DecoderResetLowHigh(NewDecoder);
    DecoderStartCode(NewDecoder);

    return NewDecoder;
}
//#####################################################################################################

//------------------------------------BEGIN OF MANAGEMENT FUNCTIONS------------------------------------

//#####################################################################################################
int GetNextBit(Decoder *MyDecoder){
    int NextBit;

    NextBit = BitInputStreamNextBit(MyDecoder->MyBitInputStream);
    if (NextBit != -1)
        return NextBit;
    else
        return 0;
}
//#####################################################################################################

//#####################################################################################################
void DecoderUnderflowBitsReview(Decoder *MyDecoder){
    MyDecoder->Code = (MyDecoder->Code & MyDecoder->MaxBitOneMask) | ((MyDecoder->Code << 1) & (MyDecoder->FullOneMask >> 1)) | GetNextBit(MyDecoder);
}
//#####################################################################################################

//#####################################################################################################
void DecoderGetInput(Decoder *MyDecoder){
    MyDecoder->Code = ((MyDecoder->Code << 1) & MyDecoder->FullOneMask) | GetNextBit(MyDecoder);
}
//#####################################################################################################

//#####################################################################################################
void DecoderUpdateLowHigh(Decoder *MyDecoder, FrequencyTable *MyFrequencyTable, int Symbol){
    long long Range = MyDecoder->High - MyDecoder->Low + 1;
    long long LastLow = MyDecoder->Low;

    if ((MyDecoder->Low >= MyDecoder->High) || ((MyDecoder->Low & MyDecoder->FullOneMask) != MyDecoder->Low) || ((MyDecoder->High & MyDecoder->FullOneMask) != MyDecoder->High)){
        printf("\nLow (%lld) or High (%lld) value out of normal range checked on 'DecoderUpdateLowHigh'!");
        exit(2);
    }
    if ((Range < MyDecoder->MinRange) || (Range > MyDecoder->MaxRange)){
        printf("\nCalculated range out of expected ranges checked on 'DecoderUpdateLowHigh'!");
        exit(2);
    }

    long FrequencyTableTotal = FrequencyTableGetTotal(MyFrequencyTable);
    long FrequencyTableLow = FrequencyTableGetLowOn(Symbol, MyFrequencyTable);
    long FrequencyTableHigh = FrequencyTableGetHighOn(Symbol, MyFrequencyTable);

    if (FrequencyTableLow == FrequencyTableHigh){
        printf("\nSymbol has zero frequency checked on 'DecoderUpdateLowHigh'!");
        exit(2);
    }
    if (FrequencyTableTotal > MyDecoder->MaxTotal){
        printf("\nSymbol amount overflow checked on 'DecoderUpdateLowHigh'!");
        exit(2);
    }

    MyDecoder->Low = LastLow + FrequencyTableLow  * Range / FrequencyTableTotal;
    MyDecoder->High = LastLow + FrequencyTableHigh * Range / FrequencyTableTotal - 1;

    while (((MyDecoder->Low ^ MyDecoder->High) & MyDecoder->MaxBitOneMask) == 0) {

        DecoderGetInput(MyDecoder);

		MyDecoder->Low = (MyDecoder->Low << 1) & MyDecoder->FullOneMask;
		MyDecoder->High = ((MyDecoder->High << 1) & MyDecoder->FullOneMask) | 1;
    }

    while ((MyDecoder->Low & ~MyDecoder->High & MyDecoder->RightMaxBitOneMask) != 0) {

		DecoderUnderflowBitsReview(MyDecoder);

		MyDecoder->Low = (MyDecoder->Low << 1) & (MyDecoder->MaxBitZeroFullOneMask);
		MyDecoder->High = ((MyDecoder->High << 1) & (MyDecoder->MaxBitZeroFullOneMask)) | MyDecoder->MaxBitOneMask | 1;
    }
}
//#####################################################################################################

//-------------------------------------END OF MANAGEMENT FUNCTIONS-------------------------------------

//------------------------------------BEGIN OF OPERATIONAL FUNCTIONS-----------------------------------

//#####################################################################################################
int DecoderGetByte(Decoder *MyDecoder, FrequencyTable *MyFrequencyTable){
    long long TotalSaver = MyFrequencyTable->Total;

    if (TotalSaver > MyDecoder->MaxTotal){
        printf("\nCan not decode because total is out of range on 'DecodeGetByte'!");
        exit(2);
    }

    long long Range = MyDecoder->High - MyDecoder->Low + 1;
    long long Offset = MyDecoder->Code - MyDecoder->Low;
    long long ValueToCheck = ((Offset + 1) * TotalSaver - 1) / Range;

    if ((ValueToCheck * Range / TotalSaver > Offset) || (ValueToCheck < 0) || (ValueToCheck >= TotalSaver)){
        printf("\nCan not decode because value to check is out of range or is invalid on 'DecodeGetByte'!");
        exit(2);
    }

    int CheckGapStart = 0;
    int CheckGapEnd = FrequencyTableGetSymbolLimit();
    int CheckGapMiddle;

    while (CheckGapEnd - CheckGapStart > 1){
        CheckGapMiddle = (CheckGapEnd + CheckGapStart) >> 1;

        if (FrequencyTableGetLowOn(CheckGapMiddle, MyFrequencyTable) > ValueToCheck)
            CheckGapEnd = CheckGapMiddle;
        else
            CheckGapStart = CheckGapMiddle;
    }

    if (CheckGapStart == CheckGapEnd){
        printf("\nCan not decode because a byte has not been recognized on 'DecodeGetByte'!");
        exit(2);
    }

    int DecodedSymbol = CheckGapStart;

    if ((FrequencyTableGetLowOn(DecodedSymbol, MyFrequencyTable) * Range / TotalSaver > Offset) || (FrequencyTableGetHighOn(DecodedSymbol, MyFrequencyTable) * Range / TotalSaver <= Offset)){
        printf("\nCan not decode because a byte has not been recognized on 'DecodeGetByte'!");
        exit(2);
    }

    DecoderUpdateLowHigh(MyDecoder, MyFrequencyTable, DecodedSymbol);

    if ((MyDecoder->Code < MyDecoder->Low) || (MyDecoder->Code > MyDecoder->High)){
        printf("\nGenerated code is out of range on 'DecodeGetByte'!");
        exit(2);
    }

    return DecodedSymbol;
}
//#####################################################################################################

//#####################################################################################################
void DecoderFinish(Decoder *MyDecoder){
    BitInputStreamCloseStream(MyDecoder->MyBitInputStream);
    free(MyDecoder->MyBitInputStream);
}
//#####################################################################################################

//-------------------------------------END OF OPERATIONAL FUNCTIONS------------------------------------
