#include <string.h>
#include "LuisaCoding.h"
#include "LuisaDecoding.h"

void HelpInformations(){
    printf("\n============================ HELP INFORMATIONS ============================\n");
    printf("ENCODE: *.exe -c Input_File_Name.ext Output_File_Name.ext contexts_amount hash_amount\n");
    printf("DECODE: *.exe -d Input_File_Name.ext Output_File_Name.ext\n");
    printf("PS: 1 <= contexts_amount <= 256\n");
    printf("PS2: -1 <= hash_amount <= contexts_amount (-1 = no hash)\n");
    printf("===========================================================================\n");
}

void ExecuteDecoding(char *InputFileName, char *OutputFileName){
    LuisaDecoder *MainDecoder;

    MainDecoder = LDCreate(InputFileName, OutputFileName);
    LDExecute(MainDecoder);
}

void ExecuteEncoding(char *InputFileName, char *OutputFileName, int ContextsAmount, int HashAmount){
    LuisaCoder *MainCoder;

    if ((ContextsAmount > 0) && (ContextsAmount < 257) && (HashAmount <= ContextsAmount) && (HashAmount >= -1)){
        MainCoder = LCCreate(InputFileName, OutputFileName, ContextsAmount, HashAmount);
        LCExecute(MainCoder);
    }
    else{
        HelpInformations();
    }
}

int main(int argc, char *argv[]){

    if (argc > 1){
        if ((strcmp(argv[1], "-c") == 0) && (argc == 6)){
            ExecuteEncoding(argv[2], argv[3], atoi(argv[4]), atoi(argv[5]));
        }
        else{
            if ((strcmp(argv[1], "-d") == 0) && (argc == 4)){
                ExecuteDecoding(argv[2], argv[3]);
            }
            else{
                HelpInformations();
            }
        }
    }
    else{
        HelpInformations();
    }

    return 0;
}
