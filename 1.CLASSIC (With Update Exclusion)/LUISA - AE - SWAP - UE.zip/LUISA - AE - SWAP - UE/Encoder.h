#if !defined(ENCODER_H)
#define ENCODER_H

#include "FrequencyTable.h"
#include "BitOutputStream.h"
#include <limits.h>

typedef struct Encoder{
    long long ManyBitsForLowHigh;
    long long FullOneMask;
    long long MaxBitZeroFullOneMask;
    long long MaxBitOneMask;
    long long RightMaxBitOneMask;
    long long MaxRange;
    long long MinRange;
    long long MaxTotal;

    long long Low;
    long long High;

    int UnderflowShiftBitsSaver;

    BitOutputStream *MyBitOutputStream;
}Encoder;

//CONSTRUCTORS
void EncoderInitiateConstant(Encoder *NewEncoder);
void EncoderResetLowHigh(Encoder *NewEncoder);
Encoder* EncoderCreate(char *OutputFileName);

//MANAGEMENT (FOR ADAPTEDENCODER)
void EncoderUnderflowBitsReview(Encoder *MyEncoder);
void EncoderSetOutput(Encoder *MyEncoder);

//OPERATIONAL
void EncoderUpdateLowHigh(Encoder *MyEncoder, FrequencyTable *MyFrequencyTable, int Symbol);
void EncoderFinish(Encoder *MyEncoder);

#endif
