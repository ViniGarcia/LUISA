#define ERROR (2)
#include "SearchNode.h"

SearchNode* SNCreate(FrequencyNode *NodeData){
    SearchNode *NewSearchNode;

    NewSearchNode = (SearchNode*) malloc(sizeof(SearchNode));
    NewSearchNode->NodeData = NodeData;
    NewSearchNode->NodeSuffix = NULL;
    NewSearchNode->NodeNext = NULL;

    return NewSearchNode;
}

SearchNode* SNInsert(SearchNode *InsertNode, ControlNode *NodeControl){
    SearchNode *Index, *Last;

    InsertNode->NodeData->NodeSearcher = InsertNode;

    if (NodeControl->NodeSearchChildren == NULL){
        NodeControl->NodeSearchChildren = InsertNode;
    }
    else{
        for(Index = NodeControl->NodeSearchChildren, Last = NULL; ((Index != NULL) &&
           (Index->NodeData->NodeSymbol < InsertNode->NodeData->NodeSymbol)); Index = Index->NodeNext){
            Last = Index;
        }
        if (Last == NULL){
            InsertNode->NodeNext = NodeControl->NodeSearchChildren;
            NodeControl->NodeSearchChildren = InsertNode;
        }
        else{
            InsertNode->NodeNext = Last->NodeNext;
            Last->NodeNext = InsertNode;
        }
    }

    return NodeControl->NodeSearchChildren;
}

SearchNode* SNSearch(int SearchSymbol, SearchNode *InitialNode){
    SearchNode *Index, *Last;

    for (Index = InitialNode, Last = NULL; ((Index != NULL) && (Index->NodeData->NodeSymbol <= SearchSymbol));
         Index = Index->NodeNext){
        Last = Index;
    }

    return Last;
}
