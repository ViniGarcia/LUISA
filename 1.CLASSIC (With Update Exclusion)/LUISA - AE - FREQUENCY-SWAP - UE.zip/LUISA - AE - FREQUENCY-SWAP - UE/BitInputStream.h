#if !defined(BITINPUTSTREAM_H)
#define BITINPUTSTREAM_H

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

typedef struct BitInputStream {
    FILE *OriginalDataFile;
    unsigned char ReadBytes[250000];
    int NextReceivedBits;
    int ManyBitsRemaining;
    int ManyBytesRemaining;
    int LastByteBlockSize;
    bool StreamEnd;
} BitInputStream;

//CONSTRUCTOR
BitInputStream* BitInputStreamCreate(char *InputFileName);

//OPERATIONAL
int BitInputStreamNextBit(BitInputStream *MyBitInputStream);
void BitInputStreamCloseStream(BitInputStream *MyBitInputStream);

#endif
