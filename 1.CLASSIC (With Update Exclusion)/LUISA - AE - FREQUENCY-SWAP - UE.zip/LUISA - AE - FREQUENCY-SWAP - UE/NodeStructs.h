#ifndef NODESTRUCTS_H
#define NODESTRUCTS_H

#include <stdlib.h>

typedef struct FrequencyNode {
    int NodeSymbol;
    int NodePosition;
    long long NodeFrequency;

    struct ControlNode *NodeControl;
    struct ControlNode *NodeChildren;
    struct SearchNode *NodeSearcher;
    struct FrequencyNode *NodeRightSibling;
    struct FrequencyNode *NodeLeftSibling;
} FrequencyNode;

typedef struct SearchNode{
    struct FrequencyNode *NodeData;
    struct SearchNode *NodeSuffix;
    struct SearchNode *NodeNext;
} SearchNode;

typedef struct ControlNode {
    int NodeTotal;

    struct FrequencyNode *NodeFrequencyChildren;
    struct SearchNode *NodeSearchChildren;
    struct SearchNode **SearchPointerChildren;
} ControlNode;

#endif
