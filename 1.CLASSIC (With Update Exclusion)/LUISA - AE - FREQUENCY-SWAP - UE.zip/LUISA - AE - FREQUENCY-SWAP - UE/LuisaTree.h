#ifndef LUISATREE_H
#define LUISATREE_H

#include "LuisaStructs.h"

LuisaTree* LTCreate(int ContextsAmount, int HashAmount);
SearchNode* LTSearch(int SearchSymbol, int *SearchLevel, LuisaTree *TreeControl);
void LTUpdate(int UpdateSymbol, SearchNode *NodeSymbol, LuisaTree *TreeControl);

#endif
