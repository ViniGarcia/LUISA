#ifndef SEARCHPOINTER_H
#define SEARCHPOINTER_H

#include "NodeStructs.h"

SearchNode* SPInsert(SearchNode *InsertNode, ControlNode *NodeControl);
SearchNode* SPSearch(int SearchSymbol, ControlNode *NodeControl);
SearchNode* SPCheck(int SearchSymbol, ControlNode *NodeControl);

#endif
