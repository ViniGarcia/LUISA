#if !defined(FREQUENCYMODEL_H)
#define FREQUENCYMODEL_H

#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#if defined(__GNUC__)
#elif defined(__WIN32)
typedef unsigned __int64 uint64_t;
typedef unsigned __int32 uint32_t;
typedef unsigned __int16 uint16_t;
typedef unsigned __int8  uint8_t;
#else
typedef unsigned long long  uint64_t;
typedef unsigned int        uint32_t;
typedef unsigned short int  uint16_t;
typedef unsigned char       uint8_t;
#endif

//Fun��o para a compress�o
void InsertModelSymbol(uint8_t);

//Fun��es para a descompress�o
void GetModelScale(uint32_t *);
int InsertModelCode(uint32_t);

//Fun��es de uso comum
void ResetModel(void);
int GetModelFrequency(uint32_t *, uint32_t *, uint32_t *);

#endif
