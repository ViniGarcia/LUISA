#include "Encoder.h"

//#####################################################################################################
void EncoderInitiateConstant(Encoder *NewEncoder){
    long long MaxLongLongValue = LLONG_MAX;

    NewEncoder->ManyBitsForLowHigh = 32;
    NewEncoder->FullOneMask = ((long long)1 << NewEncoder->ManyBitsForLowHigh)-1;
    NewEncoder->MaxBitZeroFullOneMask = (((long long)1 << (NewEncoder->ManyBitsForLowHigh-1))-1);
    NewEncoder->MaxBitOneMask = ((long long)1 << (NewEncoder->ManyBitsForLowHigh-1));
    NewEncoder->RightMaxBitOneMask = ((long long)1 << (NewEncoder->ManyBitsForLowHigh-2));
    NewEncoder->MaxRange = ((long long)1 << NewEncoder->ManyBitsForLowHigh);
    NewEncoder->MinRange = ((long long)1 << (NewEncoder->ManyBitsForLowHigh - 2))+2;

    if ((MaxLongLongValue/NewEncoder->MaxRange) < NewEncoder->MinRange)
        NewEncoder->MaxTotal = MaxLongLongValue/NewEncoder->MaxRange;
    else
        NewEncoder->MaxTotal = NewEncoder->MinRange;
}
//#####################################################################################################

//#####################################################################################################
void EncoderResetLowHigh(Encoder *NewEncoder){
    NewEncoder->Low = 0;
    NewEncoder->High = NewEncoder->FullOneMask;
    NewEncoder->UnderflowShiftBitsSaver = 0;
}
//#####################################################################################################

//#####################################################################################################
Encoder* EncoderCreate(char *OutputFileName){
    Encoder *NewEncoder = (Encoder*) malloc(sizeof(Encoder));

    EncoderInitiateConstant(NewEncoder);
    EncoderResetLowHigh(NewEncoder);
    NewEncoder->MyBitOutputStream = BitOutputStreamCreate(OutputFileName);

    return NewEncoder;
}
//#####################################################################################################


//------------------------------------BEGIN OF MANAGEMENT FUNCTIONS------------------------------------

//#####################################################################################################
void EncoderUnderflowBitsReview(Encoder *MyEncoder){
    if(MyEncoder->UnderflowShiftBitsSaver == INT_MAX){
        printf("\nUnderflow bits shifter reached maximum value on 'EncoderUnderflowBitsReview'!");
        exit(2);
    }

    MyEncoder->UnderflowShiftBitsSaver++;
}
//#####################################################################################################

//#####################################################################################################
void EncoderSetOutput(Encoder *MyEncoder){
    int Index = MyEncoder->UnderflowShiftBitsSaver;
    int BitTaker = (int)(MyEncoder->Low >> (MyEncoder->ManyBitsForLowHigh-1));

    BitOutputStreamWriteBit(MyEncoder->MyBitOutputStream, BitTaker);
    for (; Index > 0; Index--)
        BitOutputStreamWriteBit(MyEncoder->MyBitOutputStream, (BitTaker ^ 1));

    MyEncoder->UnderflowShiftBitsSaver = 0;
}
//#####################################################################################################

//-------------------------------------END OF MANAGEMENT FUNCTIONS-------------------------------------


//------------------------------------BEGIN OF OPERATIONAL FUNCTIONS-----------------------------------

//#####################################################################################################
void EncoderUpdateLowHigh(Encoder *MyEncoder, FrequencyTable *MyFrequencyTable, int Symbol){
    long long Range = MyEncoder->High - MyEncoder->Low + 1;
    long long LastLow = MyEncoder->Low;

    if ((MyEncoder->Low >= MyEncoder->High) || ((MyEncoder->Low & MyEncoder->FullOneMask) != MyEncoder->Low) || ((MyEncoder->High & MyEncoder->FullOneMask) != MyEncoder->High)){
        printf("\nLow (%lld) or High (%lld) value out of normal range checked on 'EncoderUpdateLowHigh'!");
        exit(2);
    }
    if ((Range < MyEncoder->MinRange) || (Range > MyEncoder->MaxRange)){
        printf("\nCalculated range out of expected ranges checked on 'EncoderUpdateLowHigh'!");
        exit(2);
    }

    long long FrequencyTableTotal = FrequencyTableGetTotal(MyFrequencyTable);
    long long FrequencyTableLow = FrequencyTableGetLowOn(Symbol, MyFrequencyTable);
    long long FrequencyTableHigh = FrequencyTableGetHighOn(Symbol, MyFrequencyTable);

    if (FrequencyTableLow == FrequencyTableHigh){
        printf("\nSymbol has zero frequency checked on 'EncoderUpdateLowHigh'!");
        exit(2);
    }
    if (FrequencyTableTotal > MyEncoder->MaxTotal){
        printf("\nSymbol amount overflow checked on 'EncoderUpdateLowHigh'!");
        exit(2);
    }

    MyEncoder->Low = LastLow + FrequencyTableLow  * Range / FrequencyTableTotal;
    MyEncoder->High = LastLow + FrequencyTableHigh * Range / FrequencyTableTotal - 1;

    while (((MyEncoder->Low ^ MyEncoder->High) & MyEncoder->MaxBitOneMask) == 0) {

        EncoderSetOutput(MyEncoder);

		MyEncoder->Low = (MyEncoder->Low << 1) & MyEncoder->FullOneMask;
		MyEncoder->High = ((MyEncoder->High << 1) & MyEncoder->FullOneMask) | 1;
    }

    while ((MyEncoder->Low & ~MyEncoder->High & MyEncoder->RightMaxBitOneMask) != 0) {

		EncoderUnderflowBitsReview(MyEncoder);

		MyEncoder->Low = (MyEncoder->Low << 1) & (MyEncoder->MaxBitZeroFullOneMask);
		MyEncoder->High = ((MyEncoder->High << 1) & (MyEncoder->MaxBitZeroFullOneMask)) | MyEncoder->MaxBitOneMask | 1;
    }
}
//#####################################################################################################

//#####################################################################################################
void EncoderFinish(Encoder *MyEncoder){
    EncoderSetOutput(MyEncoder);
    BitOutputStreamCloseStream(MyEncoder->MyBitOutputStream);
    free(MyEncoder->MyBitOutputStream);
}
//#####################################################################################################

//-------------------------------------END OF OPERATIONAL FUNCTIONS------------------------------------
