#define ERROR (5)
#include "LuisaDecoding.h"

int LDGetData(int DecodeSymbol, SearchNode **UpdateMatch, LuisaTree *TreeControl){
    bool CheckedValues[256] = {false};
    int CodeSearch, ContextIndex;
    FrequencyNode *ValuesIndex;

    for (ContextIndex = TreeControl->ContextsAmount; TreeControl->ContextsTree[ContextIndex] == NULL; ContextIndex--);
    for (; ContextIndex >= 0; ContextIndex--){
        if (TreeControl->ContextsTree[ContextIndex]->NodeTotal > DecodeSymbol){
            break;
        }
    }

    CodeSearch = 0;
    if ((ContextIndex < TreeControl->ContextsAmount) && (TreeControl->ContextsTree[ContextIndex+1] != NULL)){
        ContextIndex++;
        for (ValuesIndex = TreeControl->ContextsTree[ContextIndex]->NodeFrequencyChildren; ValuesIndex != NULL;
            ValuesIndex = ValuesIndex->NodeRightSibling){
            CheckedValues[ValuesIndex->NodeSymbol] = true;
            CodeSearch++;
        }
        ContextIndex--;
    }

    for (; ContextIndex >= 0; ContextIndex--){
        for (ValuesIndex = TreeControl->ContextsTree[ContextIndex]->NodeFrequencyChildren; ValuesIndex != NULL;
            ValuesIndex = ValuesIndex->NodeRightSibling){
            if (!CheckedValues[ValuesIndex->NodeSymbol]){
                CheckedValues[ValuesIndex->NodeSymbol] = true;
                CodeSearch++;
            }

            if (CodeSearch == DecodeSymbol + 1){
                UpdateMatch[0] = ValuesIndex->NodeSearcher;
                return ValuesIndex->NodeSymbol;
            }
        }
    }

    exit(ERROR);
}

int LDProcess(LuisaDecoder *MainDecoder){
    int DecodeSymbol, DecodedSymbol;
    SearchNode *UpdateMatch;

    DecodeSymbol = DecoderGetByte(MainDecoder->ArithmeticDecoder, MainDecoder->ArithmeticTable);
    if (DecodeSymbol == 256){
        return 256;
    }
    FrequencyTableInsertOn(DecodeSymbol, MainDecoder->ArithmeticTable);
    DecodedSymbol = LDGetData(DecodeSymbol, &UpdateMatch, MainDecoder->TreeControl);
    LTUpdate(DecodedSymbol, UpdateMatch, MainDecoder->TreeControl);

    return DecodedSymbol;
}

LuisaDecoder* LDCreate(char *InputFileName, char *OutputFileName){
    int ContextsAmount, HashAmount;
    LuisaDecoder *NewDecoder;

    NewDecoder = (LuisaDecoder*) malloc(sizeof(LuisaDecoder));
    NewDecoder->ArithmeticDecoder = DecoderCreate(InputFileName);
    NewDecoder->ArithmeticTable = FrequencyTableCreate();
    NewDecoder->OutputFile = fopen(OutputFileName, "wb+");
    if(NewDecoder->OutputFile == NULL){
        exit(ERROR);
    }
    ContextsAmount = DecoderGetByte(NewDecoder->ArithmeticDecoder, NewDecoder->ArithmeticTable);
    if (DecoderGetByte(NewDecoder->ArithmeticDecoder, NewDecoder->ArithmeticTable) == 2){
        HashAmount = DecoderGetByte(NewDecoder->ArithmeticDecoder, NewDecoder->ArithmeticTable);
    }
    else{
        HashAmount = -1;
    }
    NewDecoder->TreeControl = LTCreate(ContextsAmount, HashAmount);

    return NewDecoder;
}

void LDExecute(LuisaDecoder *MainDecoder){
    unsigned char ReadyBytes[500000];
    int Amount, DecodedSymbol;

    Amount = 0;
    for (DecodedSymbol = LDProcess(MainDecoder); DecodedSymbol != 256; DecodedSymbol = LDProcess(MainDecoder)){
        ReadyBytes[Amount] = DecodedSymbol;
        Amount++;

        if (Amount == 500000){
            fwrite(ReadyBytes, sizeof(char), Amount, MainDecoder->OutputFile);
            Amount = 0;
        }
    }
    if (Amount > 0){
        fwrite(ReadyBytes, sizeof(char), Amount, MainDecoder->OutputFile);
    }

    DecoderFinish(MainDecoder->ArithmeticDecoder);
    fclose(MainDecoder->OutputFile);
}
