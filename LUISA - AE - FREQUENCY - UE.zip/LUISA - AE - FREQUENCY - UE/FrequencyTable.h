#if !defined(FREQUENCYTABLE_H)
#define FREQUENCYTABLE_H

#include <stdlib.h>
#include <stdio.h>

typedef struct FrequencyTable{
    int Frequences[257];
    int Total;
} FrequencyTable;

//CONSTRUCTOR
FrequencyTable* FrequencyTableCreate();

//CHECKING
int FrequencyTableGetSymbolLimit();

//OPERATIONAL
void FrequencyTableInsertOn(int Symbol, FrequencyTable *ReceivedTable);
int FrequencyTableGetTotal(FrequencyTable *ReceivedTable);
int FrequencyTableGetFrequency(int Symbol, FrequencyTable *ReceivedTable);
int FrequencyTableGetLowOn(int Symbol, FrequencyTable *ReceivedTable);
int FrequencyTableGetHighOn(int Symbol, FrequencyTable *ReceivedTable);

#endif
