#include "FrequencyModel.h"

#define LIST_SIZE 16
#define BUFF_SIZE 65536

#define CHAIN_NO        4
#define CHAIN_ORD    1024
#define CHAIN_PRUNE   400
#define CHAIN_SWITCH  192
#define CHAIN0_ORD     16
#define CHAIN0_PRUNE  400

typedef struct freq_t freq_t;

struct freq_t {
	uint32_t total;
	uint32_t freq[256];
};

static uint32_t chain[CHAIN_ORD][CHAIN_NO+1];
static uint32_t chain_prev;
static uint32_t chain0[CHAIN0_ORD][CHAIN_NO+1];
static uint32_t chain0_prev;

static freq_t order0;
static uint32_t decode_step;

static uint8_t buff[BUFF_SIZE];
static uint32_t buff_size, buff_head, buff_half;

static uint32_t list_freq[LIST_SIZE][3];
static uint32_t list_head, list_tail, list_count;


static void AddFrequencyOnList(uint32_t l, uint32_t h, uint32_t s){
	assert(list_count < LIST_SIZE);

	list_freq[list_head][0] = l;
	list_freq[list_head][1] = h;
	list_freq[list_head][2] = s;

	list_count ++;
	if(++ list_head == LIST_SIZE)
		list_head = 0;
}

static void GetFrequencyFromList(uint32_t *l, uint32_t *h, uint32_t *s){
	assert(list_count > 0);

	*l = list_freq[list_tail][0];
	*h = list_freq[list_tail][1];
	*s = list_freq[list_tail][2];

	list_count --;
	if(++ list_tail == LIST_SIZE)
		list_tail = 0;
}

static void AddFrequencyToList(const freq_t *f, int byte){
	int i;
	uint32_t s;

	for(s = 0, i = CHAIN_NO-1; i < byte; ++ i)
		s += f->freq[i];

	assert(f->freq[i] != 0);
	AddFrequencyOnList(s, s+f->freq[i], f->total);
}

/*
 * model_init()
 * initializeaza modelul
 */
void ResetModel(void){
	uint32_t i;

	list_head = list_tail = list_count = 0;
	chain_prev = 0;
	for(i = 0; i < CHAIN_ORD; ++ i) {
		int j;
        chain[i][CHAIN_NO] = 0;
		for(j = 0; j < CHAIN_NO; ++ j) {
			chain[i][j] = CHAIN_NO - j;
            chain[i][CHAIN_NO] += chain[i][j];
        }
	}

    chain0_prev = 0;
    for(i = 0; i < CHAIN0_ORD; ++ i) {
        int j;
        for(j = 0; j < CHAIN_NO; ++ j)
            chain0[i][j] = 1;
        chain0[i][CHAIN_NO] = CHAIN_NO;
    }

	order0.total = 0;
    for(i = CHAIN_NO-1; i < 256; ++ i) {
	    order0.freq[i] = (uint32_t)(exp((-(double)i+CHAIN_NO-1.) / 9.5)*123)+1;
        order0.total += order0.freq[i];
    }

	decode_step = 0;

	buff_size = buff_head = 0;
    buff_half = 256;
}

/*
 * model_update()
 * face update la model
 */
static void UpdateModel(uint8_t byte){
	uint32_t which = (uint32_t)byte >= CHAIN_NO-1 ? CHAIN_NO-1 : (uint32_t)byte;

    chain[chain_prev][which] += 2;
    chain[chain_prev][CHAIN_NO] += 2;

    {
        static int bla = 1;

        if(which == 0) {
            if(bla == 8) {
                chain[chain_prev][0] ++;
                chain[chain_prev][CHAIN_NO] ++;
                bla = 0;
            }
            bla ++;
        }
    }

	if(chain[chain_prev][CHAIN_NO] >= CHAIN_PRUNE) {
		int j;

		chain[chain_prev][CHAIN_NO] = 0;

		for(j = 0; j < CHAIN_NO; ++ j) {
			chain[chain_prev][j] = chain[chain_prev][j]/2 + chain[chain_prev][j]%2;
			chain[chain_prev][CHAIN_NO] += chain[chain_prev][j];
		}
	}

    chain_prev = (chain_prev + which*CHAIN_ORD) / CHAIN_NO;

    chain0[chain0_prev][which] += 2;
    chain0[chain0_prev][CHAIN_NO] += 2;

    if(chain0[chain0_prev][CHAIN_NO] >= CHAIN0_PRUNE) {
        int j;

        chain0[chain0_prev][CHAIN_NO] = 0;

        for(j = 0; j < CHAIN_NO; ++ j) {
            chain0[chain0_prev][j] = chain0[chain0_prev][j]/2 + chain0[chain0_prev][j]%2;
            chain0[chain0_prev][CHAIN_NO] += chain0[chain0_prev][j];
        }
    }

    chain0_prev = (chain0_prev + which*CHAIN0_ORD) / CHAIN_NO;

	if(byte >= CHAIN_NO-1) {
		order0.freq[byte] += 7;
		order0.total += 7;

		if(buff_size < BUFF_SIZE) {
			buff[buff_size ++] = byte;
		} else {
			order0.freq[buff[buff_head]] -= 6;
			order0.total -= 6;

            order0.freq[buff[buff_half]] -= 1;
            order0.total -= 1;

			buff[buff_head] = byte;
			if(++ buff_head == BUFF_SIZE)
				buff_head = 0;
            if(++ buff_half == BUFF_SIZE)
                buff_half = 0;
		}
	}

}

/*
 * model_get_freq()
 * intoarce un numar != 0 daca mai exista frecvente in lista
 * intervalul il intoarce prin intermediul parametrilor
 */
int GetModelFrequency(uint32_t *l, uint32_t *h, uint32_t *s){
	if(list_count == 0) return 0;
	GetFrequencyFromList(l, h, s);
	return 1;
}

/*
 * model_insert_symbol()
 * primeste ca parametru un byte si insereaza in lista una sau mai multe frecvente
 * a.i. caracterul sa poata fi decodificat
 */
void InsertModelSymbol(uint8_t byte){
	uint32_t which = (uint32_t)byte >= CHAIN_NO-1 ? CHAIN_NO-1 : (uint32_t)byte;
	uint32_t s, i;

    if(chain[chain_prev][CHAIN_NO] > CHAIN_SWITCH) {
        for(s = 0, i = 0; i < which; ++ i)
            s += chain[chain_prev][i];

        AddFrequencyOnList(s, s+chain[chain_prev][which],
                      chain[chain_prev][CHAIN_NO]);
    } else {
        for(s = 0, i = 0; i < which; ++ i)
            s += chain0[chain0_prev][i];

        AddFrequencyOnList(s, s+chain0[chain0_prev][which],
                      chain0[chain0_prev][CHAIN_NO]);
    }

    if(byte >= CHAIN_NO-1)
        AddFrequencyToList(&order0, byte);

	UpdateModel(byte);
}

/*
 * model_get_scale()
 * intoarce scale pentru simbolul curent
 */
void GetModelScale(uint32_t *scale){
	if(decode_step == 0) {
        if(chain[chain_prev][CHAIN_NO] > CHAIN_SWITCH)
		    *scale = chain[chain_prev][CHAIN_NO];
        else
            *scale = chain0[chain0_prev][CHAIN_NO];
    }
	else
		*scale = order0.total;
}

/*
 * model_insert_code()
 * determina carui caracter ii corespunde codul curent
 * returneaza -1 daca mai trebuie introduse coduri
 * altfel returneaza caracterul (ca int)
 */
int InsertModelCode(uint32_t code){
	uint32_t low;
	int i;

	if(decode_step == 1) {
		assert(code < order0.total);

		low = 0; i = CHAIN_NO-1;
        	while(low + order0.freq[i] <= code)
			low += order0.freq[i ++];
		AddFrequencyOnList(low, low + order0.freq[i], order0.total);

		decode_step = 0;
		UpdateModel((uint8_t)i);
		return i;
	}

    if(chain[chain_prev][CHAIN_NO] > CHAIN_SWITCH) {
        assert(code < chain[chain_prev][CHAIN_NO]);

	    low = 0; i = 0;
	    while(low + chain[chain_prev][i] <= code)
		   low += chain[chain_prev][i ++];
	    AddFrequencyOnList(low, low + chain[chain_prev][i],
	                  chain[chain_prev][CHAIN_NO]);
    } else {
        assert(code < chain0[chain0_prev][CHAIN_NO]);

        low = 0; i = 0;
        while(low + chain0[chain0_prev][i] <= code)
           low += chain0[chain0_prev][i ++];
        AddFrequencyOnList(low, low + chain0[chain0_prev][i],
                      chain0[chain0_prev][CHAIN_NO]);
    }

	if(i == CHAIN_NO-1) {
		decode_step = 1;
		return -1;
	}

    UpdateModel((uint8_t)i);
	return i;
}
