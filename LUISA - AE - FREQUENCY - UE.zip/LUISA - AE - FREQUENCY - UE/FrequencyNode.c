#define ERROR (1)
#include "FrequencyNode.h"

FrequencyNode* FNCreate(int NodeSymbol){
    FrequencyNode *NewFrequencyNode;

    NewFrequencyNode = (FrequencyNode*) malloc(sizeof(FrequencyNode));
    NewFrequencyNode->NodeSymbol = NodeSymbol;
    NewFrequencyNode->NodePosition = -1;
    NewFrequencyNode->NodeFrequency = 1;
    NewFrequencyNode->NodeChildren = (ControlNode*) malloc(sizeof(ControlNode));
    NewFrequencyNode->NodeChildren->NodeTotal = 0;
    NewFrequencyNode->NodeChildren->NodeFrequencyChildren = NULL;
    NewFrequencyNode->NodeChildren->NodeSearchChildren = NULL;
    NewFrequencyNode->NodeChildren->SearchPointerChildren = NULL;
    NewFrequencyNode->NodeControl = NULL;
    NewFrequencyNode->NodeSearcher = NULL;
    NewFrequencyNode->NodeLeftSibling = NULL;
    NewFrequencyNode->NodeRightSibling = NULL;

    return NewFrequencyNode;
}

FrequencyNode* FNInsert(FrequencyNode *InsertNode, ControlNode *NodeControl){
    FrequencyNode *Index, *SecondaryIndex;

    InsertNode->NodeControl = NodeControl;
    if (NodeControl->NodeFrequencyChildren == NULL){
        NodeControl->NodeFrequencyChildren = InsertNode;
        InsertNode->NodePosition = 1;
    }
    else{
        for (Index = NodeControl->NodeFrequencyChildren; ((Index != NULL) && (Index->NodeFrequency != 1));
            Index = Index->NodeRightSibling){
            SecondaryIndex = Index;
        }

        if (Index == NULL){
            SecondaryIndex->NodeRightSibling = InsertNode;
            InsertNode->NodeLeftSibling = SecondaryIndex;
            InsertNode->NodePosition = SecondaryIndex->NodePosition + 1;
        }
        else{
            if (Index == NodeControl->NodeFrequencyChildren){
                NodeControl->NodeFrequencyChildren = InsertNode;
            }
            if (Index->NodeLeftSibling != NULL){
                Index->NodeLeftSibling->NodeRightSibling = InsertNode;
            }
            InsertNode->NodeRightSibling = Index;
            InsertNode->NodeLeftSibling = Index->NodeLeftSibling;
            Index->NodeLeftSibling = InsertNode;
            InsertNode->NodePosition = Index->NodePosition;
            for (; Index != NULL; Index = Index->NodeRightSibling){
                Index->NodePosition++;
            }
        }
    }

    return NodeControl->NodeFrequencyChildren;
}

FrequencyNode* FNUpdate(FrequencyNode *UpdateNode){
    FrequencyNode *Index;

    UpdateNode->NodeFrequency++;
    if (UpdateNode->NodeLeftSibling == NULL){
        return UpdateNode;
    }

    for(Index = UpdateNode->NodeLeftSibling; ((Index != NULL) && (Index->NodeFrequency <= UpdateNode->NodeFrequency));
        Index = Index->NodeLeftSibling){
        Index->NodePosition++;
        UpdateNode->NodePosition--;
    }
    if (Index == UpdateNode->NodeLeftSibling){
        return UpdateNode->NodeControl->NodeFrequencyChildren;
    }

    if (UpdateNode->NodeRightSibling != NULL){
        UpdateNode->NodeRightSibling->NodeLeftSibling = UpdateNode->NodeLeftSibling;
    }
    UpdateNode->NodeLeftSibling->NodeRightSibling = UpdateNode->NodeRightSibling;

    if (Index == NULL){
        UpdateNode->NodeControl->NodeFrequencyChildren->NodeLeftSibling = UpdateNode;
        UpdateNode->NodeRightSibling = UpdateNode->NodeControl->NodeFrequencyChildren;
        UpdateNode->NodeLeftSibling = NULL;
        UpdateNode->NodeControl->NodeFrequencyChildren = UpdateNode;
    }
    else{
        UpdateNode->NodeRightSibling = Index->NodeRightSibling;
        UpdateNode->NodeLeftSibling = Index;
        Index->NodeRightSibling->NodeLeftSibling = UpdateNode;
        Index->NodeRightSibling = UpdateNode;
    }

    return UpdateNode->NodeControl->NodeFrequencyChildren;
}
