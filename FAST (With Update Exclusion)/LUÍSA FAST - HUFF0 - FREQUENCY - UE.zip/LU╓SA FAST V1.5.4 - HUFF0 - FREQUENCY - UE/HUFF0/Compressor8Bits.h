#ifndef COMPRESSOR8BITS_H
#define COMPRESSOR8BITS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "huf.h"

#define BLOCKSIZE 131072

//FILE COMPRESSOR
void C8BFileCompress(char *InputName, char *OutputName);
//FILE DECOMPRESSOR
void C8BFileDecompress(char *InputName, char *OutputName);
//BLOCK COMPRESSOR
void C8BBlockCompress(unsigned char *InData, unsigned int ReadSize, FILE *Output);
void C8BBlockEnd(FILE *Output);
//BLOCK DECOMPRESSOR
unsigned int C8BBlockDecompress(unsigned char *OutData, FILE *Input);

#endif
