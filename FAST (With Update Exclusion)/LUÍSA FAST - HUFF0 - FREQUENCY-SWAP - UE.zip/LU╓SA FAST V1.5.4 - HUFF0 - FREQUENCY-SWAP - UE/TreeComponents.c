#include "TreeComponents.h"

TreeNode* TNDictionary(){
    int Index;
    TreeNode *NewDictionary;

    NewDictionary = MMGetTreeNode();
    NewDictionary->Children = MMGetChildrenNode();
    NewDictionary->ChildrenAmount = 256;
    for (Index = 0; Index < 256; Index++){
        NewDictionary->Children[Index].SymbolOwner = MMGetTreeNode();
        *NewDictionary->Children[Index].SymbolOwner = (TreeNode) {.Symbol = Index, .Position = Index, .Frequency = 1, .SuffixLink = NewDictionary};
        NewDictionary->Children[Index].PositionOwner = NewDictionary->Children[Index].SymbolOwner;
    }

    return NewDictionary;
}

TreeNode* TNInsert(short int Symbol, TreeNode *Node){

    if (Node->Children == NULL){
        Node->Children = MMGetChildrenNode();
    }

    Node->Children[Symbol].SymbolOwner = MMGetTreeNode();
    *Node->Children[Symbol].SymbolOwner = (TreeNode) {.Symbol = Symbol, .Position = Node->ChildrenAmount, .Frequency = 1};
    Node->Children[Node->ChildrenAmount].PositionOwner = Node->Children[Symbol].SymbolOwner;
    Node->ChildrenAmount++;

    return Node->Children[Symbol].SymbolOwner;
}

TreeNode* TNUpdate(short int Position, TreeNode *Node){
    TreeNode *Pointer;
    int Index;

    if (Position != 0){
        Pointer = Node->Children[Position].PositionOwner;
        for (Index = Position-1; ((Index >= 0) && (Node->Children[Position].PositionOwner->Frequency >= Node->Children[Index].PositionOwner->Frequency)); Index--){
            Node->Children[Index+1].PositionOwner = Node->Children[Index].PositionOwner;
            Node->Children[Index+1].PositionOwner->Position++;
        }

        if (Index != Position-1){
            Node->Children[Index+1].PositionOwner = Pointer;
            Pointer->Position = Index+1;
        }
        else{
            Node->Children[Position].PositionOwner = Node->Children[Position-1].PositionOwner;
            Node->Children[Position-1].PositionOwner = Pointer;
            Node->Children[Position].PositionOwner->Position++;
            Node->Children[Position-1].PositionOwner->Position--;
        }
        Pointer->Frequency++;
        return Pointer;
    }

    Node->Children[0].PositionOwner->Frequency++;
    return Node->Children[0].PositionOwner;
}
