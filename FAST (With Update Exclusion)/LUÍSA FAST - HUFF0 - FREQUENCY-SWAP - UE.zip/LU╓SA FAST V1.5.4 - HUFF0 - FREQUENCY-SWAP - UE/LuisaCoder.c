#include "LuisaCoder.h"
#define ERROR 3
#define BLOCKLENGHT 125000

void LCExecute(char *InputFileName, char *OutputFileName, int OrdersAmount){
    //VARI�VEIS DE EXECU��O ->
    unsigned char ReadBytes[BLOCKLENGHT];
    unsigned char WriteBytes[BLOCKLENGHT];
    int Amount, Index;
    //CODIFICADOR ->
    LuisaCoder *MainCoder;

    //===================== ETAPA DE CRIA��O DO CODIFICADOR =====================
    MainCoder = (LuisaCoder*) malloc(sizeof(LuisaCoder));
    MainCoder->ContextsTree = TCreate(OrdersAmount);
    MainCoder->InputFile = fopen(InputFileName, "rb");
    MainCoder->OutputFile = fopen(OutputFileName, "wb+");
    fputc(OrdersAmount, MainCoder->OutputFile);
    //============================================================================

    //===================== ETAPA DE EXECU��O DA CODIFICA��O =====================
    for (Amount = fread(ReadBytes, sizeof(char), BLOCKLENGHT, MainCoder->InputFile); Amount > 0; Amount = fread(ReadBytes, sizeof(char), BLOCKLENGHT, MainCoder->InputFile)){
        for (Index = 0; Index < Amount; Index++){
            WriteBytes[Index] = TFindBySymbol(ReadBytes[Index], MainCoder->ContextsTree);
        }
        C8BBlockCompress(WriteBytes, Amount, MainCoder->OutputFile);
    }
    C8BBlockEnd(MainCoder->OutputFile);
    //============================================================================

    //===================== ETAPA DE CONCLUS�O DA CODIFICA��O ====================
    fclose(MainCoder->InputFile);
    fclose(MainCoder->OutputFile);
    //============================================================================
}
