#include <string.h>
#include "LuisaCoder.h"
#include "LuisaDecoder.h"

void PrintHelp (){
    printf("=====================================================\n");
    printf("                         HELP                        \n");
    printf("Coding: *.exe -c input.ext output.ext orders_amount  \n");
    printf("Decoding: *.exe -d input.ext output.ext              \n");
    printf("=====================================================\n");
}

int main (int argc, char *argv[]){

    if (argc == 5){
        if (atoi(argv[4]) >= 0){
            if (strcmp(argv[1], "-c") == 0){
                LCExecute(argv[2], argv[3], atoi(argv[4]));
                return 0;
            }
        }
    }
    if (argc == 4){
        if (strcmp(argv[1], "-d") == 0){
            LDExecute(argv[2], argv[3]);
            return 0;
        }
    }
    PrintHelp();

    return 0;
}
