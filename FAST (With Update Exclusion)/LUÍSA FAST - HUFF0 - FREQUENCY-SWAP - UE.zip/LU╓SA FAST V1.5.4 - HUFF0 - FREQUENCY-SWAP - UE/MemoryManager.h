#ifndef MEMORYMANAGER_H
#define MEMORYMANAGER_H

#include <stdbool.h>
#include "TreeComponents.h"

bool MMAllocation(int Amount);
TreeNode* MMGetTreeNode();
ChildrenNode* MMGetChildrenNode();

#endif
