#ifndef TREECOMPONENTS_H
#define TREECOMPONENTS_H

#include <stdlib.h>
#include <stdio.h>

typedef struct ChildrenNode ChildrenNode;
typedef struct TreeNode TreeNode;

struct ChildrenNode{
    TreeNode *PositionOwner;
    TreeNode *SymbolOwner;
};

struct TreeNode{
    unsigned char Data;
    short int ChildrenAmount;
    ChildrenNode *Children;
    TreeNode *SuffixLink;
};

#include "MemoryManager.h"

TreeNode* TNDictionary();
TreeNode* TNCompressionInsert(short int Symbol, TreeNode *Node);
TreeNode* TNDecompressionInsert(short int Symbol, TreeNode *Node);
TreeNode* TNCompressionUpdate(short int Position, TreeNode *Node);
TreeNode* TNDecompressionUpdate(short int Position, TreeNode *Node);

#endif
